﻿namespace Aplikasi_Kasir
{
    partial class Form_Awal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.PanelUtama = new System.Windows.Forms.Panel();
            this.PanelSidebar = new System.Windows.Forms.Panel();
            this.btnPenjualan = new Guna.UI2.WinForms.Guna2GradientButton();
            this.btnLogin = new Guna.UI2.WinForms.Guna2GradientButton();
            this.btnFaktur = new Guna.UI2.WinForms.Guna2GradientButton();
            this.btnRefresh = new Guna.UI2.WinForms.Guna2GradientButton();
            this.btnProduk = new Guna.UI2.WinForms.Guna2GradientButton();
            this.btnAnggota = new Guna.UI2.WinForms.Guna2GradientButton();
            this.btnDetailPenjualan = new Guna.UI2.WinForms.Guna2GradientButton();
            this.btnKasir = new Guna.UI2.WinForms.Guna2GradientButton();
            this.btnDashboard = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2ControlBox1 = new Guna.UI2.WinForms.Guna2ControlBox();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.PanelTopbar = new Guna.UI2.WinForms.Guna2Panel();
            this.labelRole = new System.Windows.Forms.Label();
            this.guna2ControlBox3 = new Guna.UI2.WinForms.Guna2ControlBox();
            this.labelMenu = new System.Windows.Forms.Label();
            this.timerSidebar = new System.Windows.Forms.Timer(this.components);
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.PanelSidebar.SuspendLayout();
            this.PanelTopbar.SuspendLayout();
            this.SuspendLayout();
            // 
            // PanelUtama
            // 
            this.PanelUtama.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(63)))), ((int)(((byte)(81)))));
            this.PanelUtama.Location = new System.Drawing.Point(52, 36);
            this.PanelUtama.Name = "PanelUtama";
            this.PanelUtama.Size = new System.Drawing.Size(1887, 1063);
            this.PanelUtama.TabIndex = 14;
            // 
            // PanelSidebar
            // 
            this.PanelSidebar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.PanelSidebar.Controls.Add(this.btnPenjualan);
            this.PanelSidebar.Controls.Add(this.btnLogin);
            this.PanelSidebar.Controls.Add(this.btnFaktur);
            this.PanelSidebar.Controls.Add(this.btnRefresh);
            this.PanelSidebar.Controls.Add(this.btnProduk);
            this.PanelSidebar.Controls.Add(this.btnAnggota);
            this.PanelSidebar.Controls.Add(this.btnDetailPenjualan);
            this.PanelSidebar.Controls.Add(this.btnKasir);
            this.PanelSidebar.Controls.Add(this.btnDashboard);
            this.PanelSidebar.Location = new System.Drawing.Point(0, 36);
            this.PanelSidebar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.PanelSidebar.Name = "PanelSidebar";
            this.PanelSidebar.Size = new System.Drawing.Size(265, 1066);
            this.PanelSidebar.TabIndex = 13;
            this.PanelSidebar.MouseEnter += new System.EventHandler(this.panelSidebar_MouseEnter);
            this.PanelSidebar.MouseLeave += new System.EventHandler(this.panelSidebar_MouseLeave);
            // 
            // btnPenjualan
            // 
            this.btnPenjualan.BackColor = System.Drawing.Color.Transparent;
            this.btnPenjualan.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnPenjualan.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnPenjualan.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnPenjualan.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnPenjualan.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnPenjualan.FillColor = System.Drawing.Color.Empty;
            this.btnPenjualan.FillColor2 = System.Drawing.Color.Empty;
            this.btnPenjualan.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnPenjualan.ForeColor = System.Drawing.Color.White;
            this.btnPenjualan.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(62)))), ((int)(((byte)(103)))));
            this.btnPenjualan.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.btnPenjualan.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPenjualan.Location = new System.Drawing.Point(0, 294);
            this.btnPenjualan.Name = "btnPenjualan";
            this.btnPenjualan.Size = new System.Drawing.Size(262, 55);
            this.btnPenjualan.TabIndex = 26;
            this.btnPenjualan.Text = "💵          Penjualan";
            this.btnPenjualan.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnPenjualan.UseTransparentBackground = true;
            this.btnPenjualan.Click += new System.EventHandler(this.btnPenjualan_Click);
            // 
            // btnLogin
            // 
            this.btnLogin.BackColor = System.Drawing.Color.Transparent;
            this.btnLogin.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnLogin.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnLogin.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnLogin.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnLogin.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnLogin.FillColor = System.Drawing.Color.Empty;
            this.btnLogin.FillColor2 = System.Drawing.Color.Empty;
            this.btnLogin.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnLogin.ForeColor = System.Drawing.Color.White;
            this.btnLogin.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(62)))), ((int)(((byte)(103)))));
            this.btnLogin.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.btnLogin.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogin.Location = new System.Drawing.Point(0, 128);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(262, 55);
            this.btnLogin.TabIndex = 25;
            this.btnLogin.Text = "👤          Login";
            this.btnLogin.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnLogin.UseTransparentBackground = true;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // btnFaktur
            // 
            this.btnFaktur.BackColor = System.Drawing.Color.Transparent;
            this.btnFaktur.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnFaktur.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnFaktur.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnFaktur.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnFaktur.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnFaktur.FillColor = System.Drawing.Color.Empty;
            this.btnFaktur.FillColor2 = System.Drawing.Color.Empty;
            this.btnFaktur.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnFaktur.ForeColor = System.Drawing.Color.White;
            this.btnFaktur.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(62)))), ((int)(((byte)(103)))));
            this.btnFaktur.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.btnFaktur.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFaktur.Location = new System.Drawing.Point(0, 642);
            this.btnFaktur.Name = "btnFaktur";
            this.btnFaktur.Size = new System.Drawing.Size(262, 55);
            this.btnFaktur.TabIndex = 24;
            this.btnFaktur.Text = "🖨️          Unduh Faktur";
            this.btnFaktur.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnFaktur.UseTransparentBackground = true;
            this.btnFaktur.Click += new System.EventHandler(this.btnFaktur_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.BackColor = System.Drawing.Color.Transparent;
            this.btnRefresh.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnRefresh.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnRefresh.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnRefresh.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnRefresh.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnRefresh.FillColor = System.Drawing.Color.Empty;
            this.btnRefresh.FillColor2 = System.Drawing.Color.Empty;
            this.btnRefresh.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnRefresh.ForeColor = System.Drawing.Color.White;
            this.btnRefresh.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(62)))), ((int)(((byte)(103)))));
            this.btnRefresh.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.btnRefresh.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefresh.Location = new System.Drawing.Point(0, 586);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(262, 55);
            this.btnRefresh.TabIndex = 23;
            this.btnRefresh.Text = "🔄          Refresh";
            this.btnRefresh.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnRefresh.UseTransparentBackground = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click_1);
            // 
            // btnProduk
            // 
            this.btnProduk.BackColor = System.Drawing.Color.Transparent;
            this.btnProduk.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnProduk.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnProduk.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnProduk.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnProduk.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnProduk.FillColor = System.Drawing.Color.Empty;
            this.btnProduk.FillColor2 = System.Drawing.Color.Empty;
            this.btnProduk.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnProduk.ForeColor = System.Drawing.Color.White;
            this.btnProduk.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(62)))), ((int)(((byte)(103)))));
            this.btnProduk.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.btnProduk.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProduk.Location = new System.Drawing.Point(0, 462);
            this.btnProduk.Name = "btnProduk";
            this.btnProduk.Size = new System.Drawing.Size(262, 55);
            this.btnProduk.TabIndex = 22;
            this.btnProduk.Text = "📦          Produk";
            this.btnProduk.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnProduk.UseTransparentBackground = true;
            this.btnProduk.Click += new System.EventHandler(this.btnProduk_Click);
            // 
            // btnAnggota
            // 
            this.btnAnggota.BackColor = System.Drawing.Color.Transparent;
            this.btnAnggota.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnAnggota.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnAnggota.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnAnggota.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnAnggota.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnAnggota.FillColor = System.Drawing.Color.Empty;
            this.btnAnggota.FillColor2 = System.Drawing.Color.Empty;
            this.btnAnggota.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnAnggota.ForeColor = System.Drawing.Color.White;
            this.btnAnggota.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(62)))), ((int)(((byte)(103)))));
            this.btnAnggota.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.btnAnggota.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAnggota.Location = new System.Drawing.Point(0, 406);
            this.btnAnggota.Name = "btnAnggota";
            this.btnAnggota.Size = new System.Drawing.Size(262, 55);
            this.btnAnggota.TabIndex = 21;
            this.btnAnggota.Text = "👥          Anggota";
            this.btnAnggota.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnAnggota.UseTransparentBackground = true;
            this.btnAnggota.Click += new System.EventHandler(this.btnAnggota_Click);
            // 
            // btnDetailPenjualan
            // 
            this.btnDetailPenjualan.BackColor = System.Drawing.Color.Transparent;
            this.btnDetailPenjualan.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnDetailPenjualan.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnDetailPenjualan.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnDetailPenjualan.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnDetailPenjualan.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnDetailPenjualan.FillColor = System.Drawing.Color.Empty;
            this.btnDetailPenjualan.FillColor2 = System.Drawing.Color.Empty;
            this.btnDetailPenjualan.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnDetailPenjualan.ForeColor = System.Drawing.Color.White;
            this.btnDetailPenjualan.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(62)))), ((int)(((byte)(103)))));
            this.btnDetailPenjualan.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.btnDetailPenjualan.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDetailPenjualan.Location = new System.Drawing.Point(0, 350);
            this.btnDetailPenjualan.Name = "btnDetailPenjualan";
            this.btnDetailPenjualan.Size = new System.Drawing.Size(262, 55);
            this.btnDetailPenjualan.TabIndex = 20;
            this.btnDetailPenjualan.Text = "📄          Detail Penjualan";
            this.btnDetailPenjualan.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnDetailPenjualan.UseTransparentBackground = true;
            this.btnDetailPenjualan.Click += new System.EventHandler(this.btnDetailPenjualan_Click);
            // 
            // btnKasir
            // 
            this.btnKasir.BackColor = System.Drawing.Color.Transparent;
            this.btnKasir.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnKasir.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnKasir.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnKasir.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnKasir.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnKasir.FillColor = System.Drawing.Color.Empty;
            this.btnKasir.FillColor2 = System.Drawing.Color.Empty;
            this.btnKasir.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnKasir.ForeColor = System.Drawing.Color.White;
            this.btnKasir.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(62)))), ((int)(((byte)(103)))));
            this.btnKasir.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.btnKasir.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKasir.Location = new System.Drawing.Point(0, 238);
            this.btnKasir.Name = "btnKasir";
            this.btnKasir.Size = new System.Drawing.Size(262, 55);
            this.btnKasir.TabIndex = 2;
            this.btnKasir.Text = "🛒          Kasir";
            this.btnKasir.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnKasir.UseTransparentBackground = true;
            this.btnKasir.Click += new System.EventHandler(this.btnKasir_Click);
            // 
            // btnDashboard
            // 
            this.btnDashboard.BackColor = System.Drawing.Color.Transparent;
            this.btnDashboard.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnDashboard.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnDashboard.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnDashboard.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnDashboard.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnDashboard.FillColor = System.Drawing.Color.Empty;
            this.btnDashboard.FillColor2 = System.Drawing.Color.Empty;
            this.btnDashboard.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnDashboard.ForeColor = System.Drawing.Color.White;
            this.btnDashboard.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(62)))), ((int)(((byte)(103)))));
            this.btnDashboard.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.btnDashboard.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDashboard.Location = new System.Drawing.Point(0, 183);
            this.btnDashboard.Name = "btnDashboard";
            this.btnDashboard.Size = new System.Drawing.Size(262, 55);
            this.btnDashboard.TabIndex = 1;
            this.btnDashboard.Text = "📊          Dashboard";
            this.btnDashboard.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnDashboard.UseTransparentBackground = true;
            this.btnDashboard.Click += new System.EventHandler(this.btnDashboard_Click);
            // 
            // guna2ControlBox1
            // 
            this.guna2ControlBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ControlBox1.BackColor = System.Drawing.Color.Transparent;
            this.guna2ControlBox1.FillColor = System.Drawing.Color.Transparent;
            this.guna2ControlBox1.HoverState.BorderColor = System.Drawing.Color.Black;
            this.guna2ControlBox1.HoverState.FillColor = System.Drawing.Color.Red;
            this.guna2ControlBox1.HoverState.IconColor = System.Drawing.Color.White;
            this.guna2ControlBox1.IconColor = System.Drawing.Color.White;
            this.guna2ControlBox1.Location = new System.Drawing.Point(1848, 0);
            this.guna2ControlBox1.Name = "guna2ControlBox1";
            this.guna2ControlBox1.Size = new System.Drawing.Size(70, 33);
            this.guna2ControlBox1.TabIndex = 0;
            this.toolTip1.SetToolTip(this.guna2ControlBox1, "Exit");
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.TargetControl = this;
            // 
            // PanelTopbar
            // 
            this.PanelTopbar.BackColor = System.Drawing.Color.Black;
            this.PanelTopbar.Controls.Add(this.labelRole);
            this.PanelTopbar.Controls.Add(this.guna2ControlBox3);
            this.PanelTopbar.Controls.Add(this.labelMenu);
            this.PanelTopbar.Controls.Add(this.guna2ControlBox1);
            this.PanelTopbar.Location = new System.Drawing.Point(0, 0);
            this.PanelTopbar.Name = "PanelTopbar";
            this.PanelTopbar.Size = new System.Drawing.Size(1942, 36);
            this.PanelTopbar.TabIndex = 1;
            this.PanelTopbar.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.PanelTopbar_MouseDoubleClick);
            this.PanelTopbar.MouseDown += new System.Windows.Forms.MouseEventHandler(this.PanelTopbar_MouseDown);
            this.PanelTopbar.MouseMove += new System.Windows.Forms.MouseEventHandler(this.PanelTopbar_MouseMove);
            // 
            // labelRole
            // 
            this.labelRole.AutoSize = true;
            this.labelRole.Font = new System.Drawing.Font("Segoe UI Semibold", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelRole.ForeColor = System.Drawing.Color.White;
            this.labelRole.Location = new System.Drawing.Point(12, 7);
            this.labelRole.Name = "labelRole";
            this.labelRole.Size = new System.Drawing.Size(247, 25);
            this.labelRole.TabIndex = 29;
            this.labelRole.Text = "Anda Login Sebagai : Onwer";
            // 
            // guna2ControlBox3
            // 
            this.guna2ControlBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ControlBox3.ControlBoxType = Guna.UI2.WinForms.Enums.ControlBoxType.MinimizeBox;
            this.guna2ControlBox3.FillColor = System.Drawing.Color.Transparent;
            this.guna2ControlBox3.HoverState.BorderColor = System.Drawing.Color.Black;
            this.guna2ControlBox3.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.guna2ControlBox3.HoverState.IconColor = System.Drawing.Color.White;
            this.guna2ControlBox3.IconColor = System.Drawing.Color.White;
            this.guna2ControlBox3.Location = new System.Drawing.Point(1772, 0);
            this.guna2ControlBox3.Name = "guna2ControlBox3";
            this.guna2ControlBox3.Size = new System.Drawing.Size(70, 33);
            this.guna2ControlBox3.TabIndex = 30;
            this.toolTip1.SetToolTip(this.guna2ControlBox3, "Minimize");
            // 
            // labelMenu
            // 
            this.labelMenu.AutoSize = true;
            this.labelMenu.Font = new System.Drawing.Font("Segoe UI Semibold", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMenu.ForeColor = System.Drawing.Color.White;
            this.labelMenu.Location = new System.Drawing.Point(971, 7);
            this.labelMenu.Name = "labelMenu";
            this.labelMenu.Size = new System.Drawing.Size(101, 25);
            this.labelMenu.TabIndex = 28;
            this.labelMenu.Text = "Dashboard";
            // 
            // timerSidebar
            // 
            this.timerSidebar.Enabled = true;
            this.timerSidebar.Interval = 10;
            this.timerSidebar.Tick += new System.EventHandler(this.timerSidebar_Tick);
            // 
            // toolTip1
            // 
            this.toolTip1.IsBalloon = true;
            // 
            // Form_Awal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(120F, 120F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(1942, 1102);
            this.Controls.Add(this.PanelTopbar);
            this.Controls.Add(this.PanelSidebar);
            this.Controls.Add(this.PanelUtama);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form_Awal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form_Awal";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form_Awal_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form_Awal_FormClosed);
            this.Load += new System.EventHandler(this.Form_Awal_Load);
            this.PanelSidebar.ResumeLayout(false);
            this.PanelTopbar.ResumeLayout(false);
            this.PanelTopbar.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        internal System.Windows.Forms.Panel PanelUtama;
        private System.Windows.Forms.Panel PanelSidebar;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2GradientButton btnDashboard;
        private Guna.UI2.WinForms.Guna2GradientButton btnDetailPenjualan;
        private Guna.UI2.WinForms.Guna2GradientButton btnKasir;
        private Guna.UI2.WinForms.Guna2GradientButton btnFaktur;
        private Guna.UI2.WinForms.Guna2GradientButton btnRefresh;
        private Guna.UI2.WinForms.Guna2GradientButton btnProduk;
        private Guna.UI2.WinForms.Guna2GradientButton btnAnggota;
        private Guna.UI2.WinForms.Guna2GradientButton btnLogin;
        private Guna.UI2.WinForms.Guna2GradientButton btnPenjualan;
        private System.Windows.Forms.Timer timerSidebar;
        private Guna.UI2.WinForms.Guna2Panel PanelTopbar;
        private System.Windows.Forms.Label labelMenu;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox3;
        private System.Windows.Forms.Label labelRole;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}