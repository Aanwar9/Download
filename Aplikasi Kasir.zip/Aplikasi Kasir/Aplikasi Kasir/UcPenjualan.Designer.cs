﻿namespace Aplikasi_Kasir
{
    partial class UcPenjualan
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel3 = new System.Windows.Forms.Panel();
            this.labelTotalPenjualan = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.Box_Tanggal = new System.Windows.Forms.DateTimePicker();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.button5 = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.db_KasirKSDataSet = new Aplikasi_Kasir.Db_KasirKSDataSet();
            this.tb_PenjualanBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tb_PenjualanTableAdapter = new Aplikasi_Kasir.Db_KasirKSDataSetTableAdapters.Tb_PenjualanTableAdapter();
            this.tableAdapterManager = new Aplikasi_Kasir.Db_KasirKSDataSetTableAdapters.TableAdapterManager();
            this.iDPenjualanDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tanggalDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalCashDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalHutangDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iDAnggotaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.hapusItemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lunasiDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.db_KasirKSDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tb_PenjualanBindingSource)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.SteelBlue;
            this.panel3.Controls.Add(this.labelTotalPenjualan);
            this.panel3.Location = new System.Drawing.Point(1040, 323);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(407, 423);
            this.panel3.TabIndex = 80;
            // 
            // labelTotalPenjualan
            // 
            this.labelTotalPenjualan.AutoSize = true;
            this.labelTotalPenjualan.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTotalPenjualan.ForeColor = System.Drawing.Color.White;
            this.labelTotalPenjualan.Location = new System.Drawing.Point(4, 9);
            this.labelTotalPenjualan.Name = "labelTotalPenjualan";
            this.labelTotalPenjualan.Size = new System.Drawing.Size(111, 28);
            this.labelTotalPenjualan.TabIndex = 64;
            this.labelTotalPenjualan.Text = "Penjualan :";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SteelBlue;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.Box_Tanggal);
            this.panel1.Location = new System.Drawing.Point(1040, 71);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(407, 246);
            this.panel1.TabIndex = 79;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(4, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 28);
            this.label1.TabIndex = 41;
            this.label1.Text = "Tanggal";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(241, 86);
            this.button2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(129, 55);
            this.button2.TabIndex = 39;
            this.button2.Text = "🗑️";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(241, 148);
            this.button3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(129, 55);
            this.button3.TabIndex = 40;
            this.button3.Text = "✅";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Box_Tanggal
            // 
            this.Box_Tanggal.Location = new System.Drawing.Point(9, 42);
            this.Box_Tanggal.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Box_Tanggal.Name = "Box_Tanggal";
            this.Box_Tanggal.Size = new System.Drawing.Size(382, 22);
            this.Box_Tanggal.TabIndex = 38;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.SteelBlue;
            this.panel2.Controls.Add(this.textBox1);
            this.panel2.Controls.Add(this.comboBox2);
            this.panel2.Controls.Add(this.button5);
            this.panel2.Controls.Add(this.btnRefresh);
            this.panel2.Controls.Add(this.comboBox1);
            this.panel2.Location = new System.Drawing.Point(3, 13);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1444, 50);
            this.panel2.TabIndex = 78;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(12, 7);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(809, 34);
            this.textBox1.TabIndex = 70;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // comboBox2
            // 
            this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(1037, 7);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(137, 24);
            this.comboBox2.TabIndex = 69;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.Highlight;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Segoe UI Emoji", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(828, 5);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(55, 38);
            this.button5.TabIndex = 69;
            this.button5.Text = "❌";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRefresh.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefresh.ForeColor = System.Drawing.Color.White;
            this.btnRefresh.Location = new System.Drawing.Point(1180, 5);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(261, 38);
            this.btnRefresh.TabIndex = 19;
            this.btnRefresh.Text = "🔄   Refresh Tanggal";
            this.btnRefresh.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRefresh.UseVisualStyleBackColor = false;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(890, 7);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(137, 24);
            this.comboBox1.TabIndex = 26;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDPenjualanDataGridViewTextBoxColumn,
            this.tanggalDataGridViewTextBoxColumn,
            this.totalCashDataGridViewTextBoxColumn,
            this.totalHutangDataGridViewTextBoxColumn,
            this.iDAnggotaDataGridViewTextBoxColumn});
            this.dataGridView1.ContextMenuStrip = this.contextMenuStrip1;
            this.dataGridView1.DataSource = this.tb_PenjualanBindingSource;
            this.dataGridView1.EnableHeadersVisualStyles = false;
            this.dataGridView1.GridColor = System.Drawing.Color.White;
            this.dataGridView1.Location = new System.Drawing.Point(3, 71);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 51;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.SteelBlue;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(1027, 675);
            this.dataGridView1.TabIndex = 77;
            // 
            // db_KasirKSDataSet
            // 
            this.db_KasirKSDataSet.DataSetName = "Db_KasirKSDataSet";
            this.db_KasirKSDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tb_PenjualanBindingSource
            // 
            this.tb_PenjualanBindingSource.DataMember = "Tb_Penjualan";
            this.tb_PenjualanBindingSource.DataSource = this.db_KasirKSDataSet;
            // 
            // tb_PenjualanTableAdapter
            // 
            this.tb_PenjualanTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Tb_AnggotaTableAdapter = null;
            this.tableAdapterManager.Tb_DetailPenjualanTableAdapter = null;
            this.tableAdapterManager.Tb_PenjualanTableAdapter = this.tb_PenjualanTableAdapter;
            this.tableAdapterManager.Tb_ProdukTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = Aplikasi_Kasir.Db_KasirKSDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // iDPenjualanDataGridViewTextBoxColumn
            // 
            this.iDPenjualanDataGridViewTextBoxColumn.DataPropertyName = "ID_Penjualan";
            this.iDPenjualanDataGridViewTextBoxColumn.HeaderText = "ID_Penjualan";
            this.iDPenjualanDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.iDPenjualanDataGridViewTextBoxColumn.Name = "iDPenjualanDataGridViewTextBoxColumn";
            this.iDPenjualanDataGridViewTextBoxColumn.ReadOnly = true;
            this.iDPenjualanDataGridViewTextBoxColumn.Width = 125;
            // 
            // tanggalDataGridViewTextBoxColumn
            // 
            this.tanggalDataGridViewTextBoxColumn.DataPropertyName = "Tanggal";
            this.tanggalDataGridViewTextBoxColumn.HeaderText = "Tanggal";
            this.tanggalDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.tanggalDataGridViewTextBoxColumn.Name = "tanggalDataGridViewTextBoxColumn";
            this.tanggalDataGridViewTextBoxColumn.ReadOnly = true;
            this.tanggalDataGridViewTextBoxColumn.Width = 125;
            // 
            // totalCashDataGridViewTextBoxColumn
            // 
            this.totalCashDataGridViewTextBoxColumn.DataPropertyName = "Total_Cash";
            this.totalCashDataGridViewTextBoxColumn.HeaderText = "Total_Cash";
            this.totalCashDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.totalCashDataGridViewTextBoxColumn.Name = "totalCashDataGridViewTextBoxColumn";
            this.totalCashDataGridViewTextBoxColumn.ReadOnly = true;
            this.totalCashDataGridViewTextBoxColumn.Width = 125;
            // 
            // totalHutangDataGridViewTextBoxColumn
            // 
            this.totalHutangDataGridViewTextBoxColumn.DataPropertyName = "Total_Hutang";
            this.totalHutangDataGridViewTextBoxColumn.HeaderText = "Total_Hutang";
            this.totalHutangDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.totalHutangDataGridViewTextBoxColumn.Name = "totalHutangDataGridViewTextBoxColumn";
            this.totalHutangDataGridViewTextBoxColumn.ReadOnly = true;
            this.totalHutangDataGridViewTextBoxColumn.Width = 125;
            // 
            // iDAnggotaDataGridViewTextBoxColumn
            // 
            this.iDAnggotaDataGridViewTextBoxColumn.DataPropertyName = "ID_Anggota";
            this.iDAnggotaDataGridViewTextBoxColumn.HeaderText = "ID_Anggota";
            this.iDAnggotaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.iDAnggotaDataGridViewTextBoxColumn.Name = "iDAnggotaDataGridViewTextBoxColumn";
            this.iDAnggotaDataGridViewTextBoxColumn.ReadOnly = true;
            this.iDAnggotaDataGridViewTextBoxColumn.Width = 125;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hapusItemToolStripMenuItem,
            this.lunasiDataToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(156, 52);
            // 
            // hapusItemToolStripMenuItem
            // 
            this.hapusItemToolStripMenuItem.Name = "hapusItemToolStripMenuItem";
            this.hapusItemToolStripMenuItem.Size = new System.Drawing.Size(210, 24);
            this.hapusItemToolStripMenuItem.Text = "Hapus Item";
            this.hapusItemToolStripMenuItem.Click += new System.EventHandler(this.hapusItemToolStripMenuItem_Click);
            // 
            // lunasiDataToolStripMenuItem
            // 
            this.lunasiDataToolStripMenuItem.Name = "lunasiDataToolStripMenuItem";
            this.lunasiDataToolStripMenuItem.Size = new System.Drawing.Size(210, 24);
            this.lunasiDataToolStripMenuItem.Text = "Lunasi Data";
            this.lunasiDataToolStripMenuItem.Click += new System.EventHandler(this.lunasiDataToolStripMenuItem_Click);
            // 
            // UcPenjualan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.dataGridView1);
            this.Name = "UcPenjualan";
            this.Size = new System.Drawing.Size(1584, 1217);
            this.Load += new System.EventHandler(this.UcPenjualan_Load);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.db_KasirKSDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tb_PenjualanBindingSource)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label labelTotalPenjualan;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.DateTimePicker Box_Tanggal;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDPenjualanDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tanggalDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalCashDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalHutangDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDAnggotaDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource tb_PenjualanBindingSource;
        private Db_KasirKSDataSet db_KasirKSDataSet;
        private Db_KasirKSDataSetTableAdapters.Tb_PenjualanTableAdapter tb_PenjualanTableAdapter;
        private Db_KasirKSDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem hapusItemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lunasiDataToolStripMenuItem;
    }
}
