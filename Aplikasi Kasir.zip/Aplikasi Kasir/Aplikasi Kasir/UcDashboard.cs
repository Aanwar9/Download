﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aplikasi_Kasir
{
    public partial class UcDashboard : UserControl
    {
        // 🔹 Satu sumber data aktif
        private DataView viewPenjualanAktif;
        public UcDashboard()
        {
            InitializeComponent();
        }
        // =====================================
        // LOAD DASHBOARD
        // =====================================
        private void UcDashboard_Load(object sender, EventArgs e)
        {
            // Load data
            tb_AnggotaTableAdapter.Fill(db_KasirKSDataSet.Tb_Anggota);
            tb_PenjualanTableAdapter.Fill(db_KasirKSDataSet.Tb_Penjualan);
            tb_ProdukTableAdapter.Fill(db_KasirKSDataSet.Tb_Produk);
            tb_DetailPenjualanTableAdapter.Fill(db_KasirKSDataSet.Tb_DetailPenjualan);

            // Default tanggal hari ini
            Box_Tanggal1.Text = DateTime.Now.ToString("yyyy-MM-dd");
            Box_Tanggal2.Text = DateTime.Now.ToString("yyyy-MM-dd");

            // Default view
            viewPenjualanAktif = new DataView(db_KasirKSDataSet.Tb_Penjualan);

            // Default checkbox tanggal NONAKTIF
            checkBoxTanggal.Checked = false;
            Box_Tanggal1.Enabled = false;
            Box_Tanggal2.Enabled = false;

            // Terapkan filter awal (tanpa filter)
            ApplyFilter();
        }
        // =====================================
        // FUNGSI FILTER UTAMA
        // =====================================
        private void ApplyFilter()
        {
            DataTable sumber = db_KasirKSDataSet.Tb_Penjualan;
            DataTable hasil = sumber.Clone();

            bool filterTanggal = checkBoxTanggal.Checked;

            DateTime tglAwal = DateTime.MinValue;
            DateTime tglAkhir = DateTime.MaxValue;

            if (filterTanggal)
            {
                DateTime.TryParse(Box_Tanggal1.Text, out tglAwal);
                DateTime.TryParse(Box_Tanggal2.Text, out tglAkhir);
            }

            bool pakaiAnggota = int.TryParse(textBox7.Text.Trim(), out int idAnggota);

            foreach (DataRow row in sumber.Rows)
            {
                bool cocok = true;

                // 🔹 FILTER ANGGOTA
                if (pakaiAnggota)
                {
                    if (row["ID_Anggota"] == DBNull.Value ||
                        Convert.ToInt32(row["ID_Anggota"]) != idAnggota)
                    {
                        cocok = false;
                    }
                }

                // 🔹 FILTER TANGGAL
                if (filterTanggal && row["Tanggal"] != DBNull.Value)
                {
                    DateTime tgl = Convert.ToDateTime(row["Tanggal"]);
                    if (tgl < tglAwal || tgl > tglAkhir)
                        cocok = false;
                }

                if (cocok)
                    hasil.ImportRow(row);
            }

            viewPenjualanAktif = hasil.DefaultView;

            UpdateLabelNotif(pakaiAnggota, filterTanggal, tglAwal, tglAkhir);
            UpdateLabelBatasTanggalDariData();
        }
        private void HitungTotalAnggota()
        {
            if (viewPenjualanAktif == null || viewPenjualanAktif.Count == 0)
            {
                labelTotalAnggota.Text = "👥 Total Anggota : 0";
                return;
            }

            HashSet<int> anggotaUnik = new HashSet<int>();

            foreach (DataRowView row in viewPenjualanAktif)
            {
                if (row[4] == DBNull.Value) continue; // ID_Anggota

                int idAnggota = Convert.ToInt32(row[4]);
                anggotaUnik.Add(idAnggota);
            }

            labelTotalAnggota.Text =
                "👥 Total Anggota : " + anggotaUnik.Count.ToString("N0");
        }
        private void HitungTotalPenjualan()
        {
            if (viewPenjualanAktif == null || viewPenjualanAktif.Count == 0)
            {
                labelTotalPenjualan.Text = "💵 Total Penjualan : 0";
                labelTotalCash.Text = "💲 Total Cash : 0";
                labelTotalHutang.Text = "💸 Total Hutang : 0";
                return;
            }

            int totalTransaksi = 0;
            decimal totalCash = 0;
            decimal totalHutang = 0;

            foreach (DataRowView row in viewPenjualanAktif)
            {
                totalTransaksi++;

                if (row[2] != DBNull.Value)
                    totalCash += Convert.ToDecimal(row[2]); // Total_Cash

                if (row[3] != DBNull.Value)
                    totalHutang += Convert.ToDecimal(row[3]); // Total_Hutang
            }

            labelTotalPenjualan.Text =
                "💵 Total Penjualan : " + totalTransaksi.ToString("N0");

            labelTotalCash.Text =
                "💲 Total Cash : " + totalCash.ToString("N0");

            labelTotalHutang.Text =
                "💸 Total Hutang : " + totalHutang.ToString("N0");
        }
        private void HitungDetailPenjualan()
        {
            if (viewPenjualanAktif == null || viewPenjualanAktif.Count == 0)
            {
                labelTotalJumlahBeli.Text = "🛒 Total Jumlah Beli : 0";
                labelTotalSemuaHarga.Text = "💰 Total Semua Harga : 0";
                return;
            }

            var idPenjualanAktif = viewPenjualanAktif
                .Cast<DataRowView>()
                .Select(r => Convert.ToInt32(r[0])) // ID_Penjualan
                .ToList();

            int totalJumlahBeli = 0;
            decimal totalHarga = 0;

            foreach (DataRow row in db_KasirKSDataSet.Tb_DetailPenjualan.Rows)
            {
                if (row.RowState == DataRowState.Deleted) continue;

                int idPenjualan = Convert.ToInt32(row[1]); // ID_Penjualan

                if (!idPenjualanAktif.Contains(idPenjualan)) continue;

                if (row[3] != DBNull.Value)
                    totalJumlahBeli += Convert.ToInt32(row[3]); // Jumlah_Beli

                if (row[5] != DBNull.Value)
                    totalHarga += Convert.ToDecimal(row[5]); // Total_Harga
            }

            labelTotalJumlahBeli.Text =
                "🛒 Total Jumlah Beli : " + totalJumlahBeli.ToString("N0");

            labelTotalSemuaHarga.Text =
                "💰 Total Semua Harga : " + totalHarga.ToString("N0");
        }
        private void HitungTotalProduk()
        {
            if (viewPenjualanAktif == null || viewPenjualanAktif.Count == 0)
            {
                labelTotalProduk.Text = "📦 Total Jenis Produk : 0";
                return;
            }

            var idPenjualanAktif = viewPenjualanAktif
                .Cast<DataRowView>()
                .Select(r => Convert.ToInt32(r[0])) // ID_Penjualan
                .ToHashSet();

            HashSet<int> produkUnik = new HashSet<int>();

            foreach (DataRow row in db_KasirKSDataSet.Tb_DetailPenjualan.Rows)
            {
                if (row.RowState == DataRowState.Deleted) continue;

                int idPenjualan = Convert.ToInt32(row[1]);
                if (!idPenjualanAktif.Contains(idPenjualan)) continue;

                if (row[2] == DBNull.Value) continue; // ID_Produk

                int idProduk = Convert.ToInt32(row[2]);
                produkUnik.Add(idProduk);
            }

            labelTotalProduk.Text =
                "📦 Total Jenis Produk : " + produkUnik.Count.ToString("N0");
        }
        private void HitungSemuaRingkasan()
        {
            HitungTotalAnggota();
            HitungTotalProduk();
            HitungTotalPenjualan();
            HitungDetailPenjualan();
        }
        private void UpdateLabelNotif(bool anggota, bool tanggal, DateTime tglAwal, DateTime tglAkhir)
        {
            if (!anggota && !tanggal)
            {
                labelNotif.Text = "📌 Tanpa Filter";
                return;
            }

            bool satuHari = tanggal && tglAwal.Date == tglAkhir.Date;

            if (anggota && !tanggal)
                labelNotif.Text = "📌 Filter Anggota";

            else if (!anggota && tanggal && satuHari)
                labelNotif.Text = "📌 Filter Tanggal (1 Hari)";

            else if (!anggota && tanggal)
                labelNotif.Text = "📌 Filter Tanggal";

            else if (anggota && tanggal && satuHari)
                labelNotif.Text = "📌 Filter Anggota + Tanggal (1 Hari)";

            else if (anggota && tanggal)
                labelNotif.Text = "📌 Filter Anggota + Tanggal";
        }
        private void UpdateLabelBatasTanggalDariData()
        {
            if (viewPenjualanAktif == null || viewPenjualanAktif.Count == 0)
            {
                labelBatasTanggal.Text = "📅 -";
                return;
            }

            DateTime? tglMin = null;
            DateTime? tglMax = null;

            foreach (DataRowView row in viewPenjualanAktif)
            {
                if (row["Tanggal"] == DBNull.Value) continue;

                DateTime tgl = Convert.ToDateTime(row["Tanggal"]);

                if (tglMin == null || tgl < tglMin) tglMin = tgl;
                if (tglMax == null || tgl > tglMax) tglMax = tgl;
            }

            if (tglMin != null && tglMax != null)
            {
                int jumlahHari = (tglMax.Value.Date - tglMin.Value.Date).Days + 1;

                string teksHari = jumlahHari == 1
                    ? "1 Hari"
                    : jumlahHari + " Hari";

                labelBatasTanggal.Text =
                    $"📅 {tglMin:dd/MM/yyyy} - {tglMax:dd/MM/yyyy} ({teksHari})";
            }
            else
            {
                labelBatasTanggal.Text = "📅 -";
            }
        }
        // =====================================
        // BUTTON: REFRESH ANGGOTA
        // =====================================
        private void btnRefreshAnggota_Click(object sender, EventArgs e)
        {
            textBox7.Text = "";
            ApplyFilter();
        }
        // =====================================
        // BUTTON: REFRESH TANGGAL
        // =====================================
        private void btnRefreshTanggal_Click(object sender, EventArgs e)
        {
            Box_Tanggal1.Text = DateTime.Now.ToString("yyyy-MM-dd");
            Box_Tanggal2.Text = DateTime.Now.ToString("yyyy-MM-dd");
            ApplyFilter();
        }
        // =====================================
        // BUTTON: REFRESH SEMUA INPUT
        // =====================================
        private void btnRefreshKotakTeks_Click(object sender, EventArgs e)
        {
            textBox7.Text = "";
            Box_Tanggal1.Text = DateTime.Now.ToString("yyyy-MM-dd");
            Box_Tanggal2.Text = DateTime.Now.ToString("yyyy-MM-dd");
            ApplyFilter();
        }
        // =====================================
        // BUTTON: HITUNG TOTAL DATA
        // =====================================
        private void btnTotalDataLabel_Click(object sender, EventArgs e)
        {
            HitungSemuaRingkasan();
        }
        // =====================================
        // BUTTON: DIAGRAM (DIKOSONGKAN)
        // =====================================
        private void btnDiagramChart_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Chart sementara dinonaktifkan",
               "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        // =====================================
        // BUTTON: SCROLL KE ATAS
        // =====================================
        private void btnUp_Click(object sender, EventArgs e)
        {
            this.VerticalScroll.Value = 0;
        }

        private void checkBoxTanggal_CheckedChanged(object sender, EventArgs e)
        {
            bool aktif = checkBoxTanggal.Checked;

            Box_Tanggal1.Enabled = aktif;
            Box_Tanggal2.Enabled = aktif;

            if (!aktif)
            {
                // Reset ke hari ini biar konsisten
                Box_Tanggal1.Value = DateTime.Now;
                Box_Tanggal2.Value = DateTime.Now;
            }

            ApplyFilter();
        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {
            ApplyFilter();
        }

        private void Box_Tanggal1_ValueChanged(object sender, EventArgs e)
        {
            if (checkBoxTanggal.Checked)
                ApplyFilter();
        }

        private void Box_Tanggal2_ValueChanged(object sender, EventArgs e)
        {
            if (checkBoxTanggal.Checked)
                ApplyFilter();
        }
    }
}
