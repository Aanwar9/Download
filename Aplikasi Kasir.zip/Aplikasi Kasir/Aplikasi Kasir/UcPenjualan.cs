﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aplikasi_Kasir
{
    public partial class UcPenjualan : UserControl
    {
        public UcPenjualan()
        {
            InitializeComponent();
        }
        // =========================
        // LOAD & INIT
        // =========================
        private void UcPenjualan_Load(object sender, EventArgs e)
        {
            tb_PenjualanTableAdapter.Fill(db_KasirKSDataSet.Tb_Penjualan);

            InisialisasiComboBox();
            LoadDataPenjualan();
            TampilkanTotalPenjualan();

            Box_Tanggal.Text = DateTime.Now.ToString("yyyy-MM-dd");
        }
        private void InisialisasiComboBox()
        {
            comboBox1.Items.AddRange(new object[]
            {
                "ID Penjualan",
                "Tanggal : Hari",
                "Tanggal : Bulan",
                "Tanggal : Tahun",
                "Total Cash",
                "Total Hutang",
                "ID Anggota"
            });

            comboBox2.Items.AddRange(new object[]
            {
                "Ascending",
                "Descending"
            });

            comboBox1.SelectedIndex = 0;
            comboBox2.SelectedIndex = 0;
        }

        // =========================
        // UTIL
        // =========================
        private void LoadDataPenjualan()
        {
            dataGridView1.DataSource =
                tb_PenjualanTableAdapter.GetData().ToList();
        }

        private void TampilkanTotalPenjualan()
        {
            int total = dataGridView1.Rows
                .Cast<DataGridViewRow>()
                .Count(r => !r.IsNewRow);

            labelTotalPenjualan.Text =
                "Penjualan:" + Environment.NewLine + total;
        }

        private int? AmbilIdTerpilih()
        {
            if (dataGridView1.SelectedRows.Count == 0)
                return null;

            return Convert.ToInt32(
                dataGridView1.SelectedRows[0].Cells[0].Value
            );
        }

        // =========================
        // SORTING
        // =========================
        private void LakukanSortingPenjualan()
        {
            if (comboBox1.SelectedItem == null || comboBox2.SelectedItem == null)
                return;

            var data = dataGridView1.DataSource as
                System.Collections.Generic.List<Db_KasirKSDataSet.Tb_PenjualanRow>;

            if (data == null) return;

            bool asc = comboBox2.SelectedItem.ToString() == "Ascending";

            switch (comboBox1.SelectedItem.ToString())
            {
                case "ID Penjualan":
                    data = asc ? data.OrderBy(x => x.ID_Penjualan).ToList()
                               : data.OrderByDescending(x => x.ID_Penjualan).ToList();
                    break;

                case "Tanggal : Hari":
                    data = asc ? data.OrderBy(x => x.Tanggal.Day).ToList()
                               : data.OrderByDescending(x => x.Tanggal.Day).ToList();
                    break;

                case "Tanggal : Bulan":
                    data = asc ? data.OrderBy(x => x.Tanggal.Month).ToList()
                               : data.OrderByDescending(x => x.Tanggal.Month).ToList();
                    break;

                case "Tanggal : Tahun":
                    data = asc ? data.OrderBy(x => x.Tanggal.Year).ToList()
                               : data.OrderByDescending(x => x.Tanggal.Year).ToList();
                    break;

                case "Total Cash":
                    data = asc ? data.OrderBy(x => x.Total_Cash).ToList()
                               : data.OrderByDescending(x => x.Total_Cash).ToList();
                    break;

                case "Total Hutang":
                    data = asc ? data.OrderBy(x => x.Total_Hutang).ToList()
                               : data.OrderByDescending(x => x.Total_Hutang).ToList();
                    break;

                case "ID Anggota":
                    data = asc ? data.OrderBy(x => x.ID_Anggota).ToList()
                               : data.OrderByDescending(x => x.ID_Anggota).ToList();
                    break;
            }

            dataGridView1.DataSource = data;
        }
        // =========================
        // FILTER
        // =========================
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string filter = textBox1.Text.Trim();
            var data = tb_PenjualanTableAdapter.GetData();

            if (string.IsNullOrEmpty(filter))
            {
                dataGridView1.DataSource = data.ToList();
                LakukanSortingPenjualan();
                return;
            }

            var hasil = data.Where(p =>
                comboBox1.SelectedItem.ToString() == "ID Penjualan" && p.ID_Penjualan.ToString().Contains(filter) ||
                comboBox1.SelectedItem.ToString() == "Tanggal : Hari" && p.Tanggal.Day.ToString().Contains(filter) ||
                comboBox1.SelectedItem.ToString() == "Tanggal : Bulan" && p.Tanggal.Month.ToString().Contains(filter) ||
                comboBox1.SelectedItem.ToString() == "Tanggal : Tahun" && p.Tanggal.Year.ToString().Contains(filter) ||
                comboBox1.SelectedItem.ToString() == "Total Cash" && p.Total_Cash.ToString("0.##").Contains(filter) ||
                comboBox1.SelectedItem.ToString() == "Total Hutang" && p.Total_Hutang.ToString("0.##").Contains(filter) ||
                comboBox1.SelectedItem.ToString() == "ID Anggota" && p.ID_Anggota.ToString().Contains(filter)
            ).ToList();

            dataGridView1.DataSource = hasil;
            LakukanSortingPenjualan();
        }
        // =========================
        // AKSI DATA
        // =========================
        private void HapusPenjualan()
        {
            var id = AmbilIdTerpilih();
            if (id == null) return;

            if (MessageBox.Show("Hapus data ini?",
                "Konfirmasi", MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning) != DialogResult.Yes)
                return;

            tb_PenjualanTableAdapter.HapusPenjualan(id.Value);
            LoadDataPenjualan();
            TampilkanTotalPenjualan();
        }

        private void LunasiPenjualan()
        {
            var id = AmbilIdTerpilih();
            if (id == null) return;

            var data = tb_PenjualanTableAdapter
                .GetData()
                .FirstOrDefault(x => x.ID_Penjualan == id.Value);

            if (data == null) return;

            if (!DateTime.TryParse(Box_Tanggal.Text, out DateTime tanggal))
            {
                MessageBox.Show("Format tanggal tidak valid!", "Error");
                return;
            }

            data.Total_Cash += data.Total_Hutang;
            data.Total_Hutang = 0;
            data.Tanggal = tanggal;

            tb_PenjualanTableAdapter.Update(data);

            LoadDataPenjualan();
            MessageBox.Show("✅ Pelunasan berhasil!", "Sukses");
        }
        // =========================
        // EVENT UI
        // =========================
        private void hapusItemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            HapusPenjualan();
        }

        private void lunasiDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LunasiPenjualan();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            HapusPenjualan();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            LunasiPenjualan();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            Box_Tanggal.Text = DateTime.Now.ToString("yyyy-MM-dd");
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            LakukanSortingPenjualan();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            LakukanSortingPenjualan();
        }
    }
}
