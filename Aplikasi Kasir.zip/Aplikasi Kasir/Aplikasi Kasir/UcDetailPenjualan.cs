﻿using Aplikasi_Kasir.Db_KasirKSDataSetTableAdapters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aplikasi_Kasir
{
    public partial class UcDetailPenjualan : UserControl
    {
        public UcDetailPenjualan()
        {
            InitializeComponent();
        }
        // =========================
        // LOAD & INIT
        // =========================
        private void UcDetailPenjualan_Load(object sender, EventArgs e)
        {
            tb_DetailPenjualanTableAdapter.Fill(db_KasirKSDataSet.Tb_DetailPenjualan);

            InisialisasiComboBox();
            LoadDataDetail();
            TampilkanTotalDetail();

            Box_Tanggal.Text = DateTime.Now.ToString("yyyy-MM-dd");
        }
        private void InisialisasiComboBox()
        {
            comboBox1.Items.AddRange(new object[]
            {
                "ID Detail",
                "ID Penjualan",
                "ID Produk",
                "Jumlah Beli",
                "Diskon",
                "Sub Total"
            });

            comboBox2.Items.AddRange(new object[]
            {
                "Ascending",
                "Descending"
            });

            comboBox1.SelectedIndex = 0;
            comboBox2.SelectedIndex = 0;
        }

        // =========================
        // UTIL
        // =========================
        private void LoadDataDetail()
        {
            dataGridView1.DataSource =
                tb_DetailPenjualanTableAdapter.GetData().ToList();
        }

        private void TampilkanTotalDetail()
        {
            int total = dataGridView1.Rows
                .Cast<DataGridViewRow>()
                .Count(r => !r.IsNewRow);

            labelTotalDetailPenjualan.Text =
                "Detail Penjualan:" + Environment.NewLine + total;
        }

        private int? AmbilIdTerpilih()
        {
            if (dataGridView1.SelectedRows.Count == 0)
                return null;

            return Convert.ToInt32(
                dataGridView1.SelectedRows[0].Cells[0].Value
            );
        }

        // =========================
        // SORTING
        // =========================
        private void LakukanSortingDetail()
        {
            if (comboBox1.SelectedItem == null || comboBox2.SelectedItem == null)
                return;

            var data = dataGridView1.DataSource as
                List<Db_KasirKSDataSet.Tb_DetailPenjualanRow>;

            if (data == null) return;

            bool asc = comboBox2.SelectedItem.ToString() == "Ascending";

            switch (comboBox1.SelectedItem.ToString())
            {
                case "ID Detail":
                    data = asc ? data.OrderBy(x => x.ID_Detail).ToList()
                               : data.OrderByDescending(x => x.ID_Detail).ToList();
                    break;

                case "ID Penjualan":
                    data = asc ? data.OrderBy(x => x.ID_Penjualan).ToList()
                               : data.OrderByDescending(x => x.ID_Penjualan).ToList();
                    break;

                case "ID Produk":
                    data = asc ? data.OrderBy(x => x.ID_Produk).ToList()
                               : data.OrderByDescending(x => x.ID_Produk).ToList();
                    break;

                case "Jumlah Beli":
                    data = asc ? data.OrderBy(x => x.Jumlah_Beli).ToList()
                               : data.OrderByDescending(x => x.Jumlah_Beli).ToList();
                    break;

                case "Diskon":
                    data = asc ? data.OrderBy(x => x.Diskon).ToList()
                               : data.OrderByDescending(x => x.Diskon).ToList();
                    break;

                case "Sub Total":
                    data = asc ? data.OrderBy(x => x.Sub_Total).ToList()
                               : data.OrderByDescending(x => x.Sub_Total).ToList();
                    break;
            }

            dataGridView1.DataSource = data;
        }
        // =========================
        // FILTER
        // =========================
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string filter = textBox1.Text.Trim();
            var data = tb_DetailPenjualanTableAdapter.GetData();

            if (string.IsNullOrEmpty(filter))
            {
                dataGridView1.DataSource = data.ToList();
                LakukanSortingDetail();
                return;
            }

            var hasil = data.Where(p =>
                comboBox1.SelectedItem.ToString() == "ID Detail" && p.ID_Detail.ToString().Contains(filter) ||
                comboBox1.SelectedItem.ToString() == "ID Penjualan" && p.ID_Penjualan.ToString().Contains(filter) ||
                comboBox1.SelectedItem.ToString() == "ID Produk" && p.ID_Produk.ToString().Contains(filter) ||
                comboBox1.SelectedItem.ToString() == "Jumlah Beli" && p.Jumlah_Beli.ToString().Contains(filter) ||
                comboBox1.SelectedItem.ToString() == "Diskon" && p.Diskon.ToString().Contains(filter) ||
                comboBox1.SelectedItem.ToString() == "Sub Total" && p.Sub_Total.ToString("0.##").Contains(filter)
            ).ToList();

            dataGridView1.DataSource = hasil;
            LakukanSortingDetail();
        }
        // =========================
        // AKSI DATA
        // =========================
        private void HapusDetail()
        {
            var id = AmbilIdTerpilih();
            if (id == null) return;

            if (MessageBox.Show(
                "Apakah Anda ingin menghapus data ini?",
                "Konfirmasi",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning) != DialogResult.Yes)
                return;

            tb_DetailPenjualanTableAdapter.HapusDetailPenjualan(id.Value);

            LoadDataDetail();
            TampilkanTotalDetail();

            MessageBox.Show("Data berhasil dihapus!", "Informasi");
        }
        // =========================
        // EVENT UI
        // =========================
        private void hapusItemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            HapusDetail();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            HapusDetail();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            LakukanSortingDetail();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            LakukanSortingDetail();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            Box_Tanggal.Text = DateTime.Now.ToString("yyyy-MM-dd");
        }
        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }

        private void dataGridView1_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
