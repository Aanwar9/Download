﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aplikasi_Kasir
{
    public partial class Form_Login : Form
    {

        // Dummy data login (sementara)
        private readonly Dictionary<string, string> dummyPasswords =
            new Dictionary<string, string>
        {
            { "Owner", "owner123" },
            { "Manager", "manager321" },
            { "Kasir", "kasir001" },
            { "Gudang", "gudang456" },
            { "Akuntan", "akuntan789" }
        };
        public Form_Login()
        {
            InitializeComponent();
        }
        private void Form_Login_Load(object sender, EventArgs e)
        {
            // Role
            comboBoxRole.Items.AddRange(new object[]
            {
                "Owner",
                "Manager",
                "Kasir",
                "Gudang",
                "Akuntan"
            });

            comboBoxRole.SelectedIndex = 0;

            // Password
            txtPassword.PasswordChar = '●';
            this.AcceptButton = btnLogin;

            lblError.Visible = false;
        }
        private void chkShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            txtPassword.PasswordChar = chkShowPassword.Checked ? '\0' : '●';
        }
        private void btnLogin_Click(object sender, EventArgs e)
        {

            lblError.Visible = false; // reset error login

            string role = comboBoxRole.SelectedItem?.ToString();
            string password = txtPassword.Text.Trim();

            if (string.IsNullOrEmpty(password))
            {
                ShowLoginError("Password wajib diisi.");
                return;
            }

            if (!dummyPasswords.ContainsKey(role))
            {
                ShowLoginError("Role tidak valid.");
                return;
            }

            if (password != dummyPasswords[role])
            {
                ShowLoginError("Password salah.");
                return;
            }

            // Login sukses
            Form_Awal frm = new Form_Awal(role);
            frm.Show();
            this.Hide();
        }
        private void ShowLoginError(string message)
        {
            lblError.Text = message;
            lblError.Visible = true;

            txtPassword.BorderColor =
                Color.FromArgb(250, 119, 124);
            txtPassword.FocusedState.BorderColor =
                Color.FromArgb(250, 119, 124);
        }
    }
}
