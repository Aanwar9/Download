﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aplikasi_Kasir
{
    public partial class UcKasir : UserControl
    {
        // =============================
        // 🔹 GLOBAL STATE
        // =============================
        long Nourut;
        long AutoDetailUrut;

        DataTable TempDetailJoin = new DataTable();
        Dictionary<long, long> StokSementara = new Dictionary<long, long>();
        Dictionary<string, string> KolomMap = new Dictionary<string, string>();

        public bool TransaksiSudahDisimpan { get; private set; }
        private Form parentForm;

        // =============================
        // 🔹 CONSTRUCTOR
        // =============================
        public UcKasir()
        {
            InitializeComponent();

            TransaksiSudahDisimpan = false;

            this.Load += UcKasir_Load;
        }

        // =============================
        // 🔹 LOAD
        // =============================
        private void UcKasir_Load(object sender, EventArgs e)
        {
            parentForm = FindForm();

            LoadDatabase();
            SetupTempTable();
            SetupComboBox();
        }
        // =============================
        // 🔹 HELPER METHODS
        // =============================
        private decimal ParseDecimal(string text)
        {
            string clean = new string(text.Where(c => char.IsDigit(c) || c == ',' || c == '.').ToArray());

            decimal result;
            if (!decimal.TryParse(clean, out result))
                decimal.TryParse(clean,
                    System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture,
                    out result);

            return result;
        }
        private void ResetFormKasir()
        {
            Box_Diskon.Text = "0";
            Box_IdAnggota.Clear();
            Box_NamaAnggota.Clear();
            Box_IdProduk.Clear();
            Box_KodeProduk.Clear();
            Box_Kuantitas.Clear();
            Box_NamaProduk.Clear();
            Box_HargaProduk.Clear();
            Box_StokProduk.Clear();
            Box_JumlahBeli.Clear();
            Box_SubTotal.Clear();
            Box_Bayar.Clear();
            Box_Kembalian.Clear();

            GrandTotal.Text = "Rp0";
            GrandBanyak.Text = "0";
        }
        private void LoadDatabase()
        {
            // Load semua table yang dibutuhkan kasir
            this.joinTabelKasirTableAdapter.Fill(this.db_KasirKSDataSet.JoinTabelKasir);
            this.tb_DetailPenjualanTableAdapter.Fill(this.db_KasirKSDataSet.Tb_DetailPenjualan);
            this.tb_PenjualanTableAdapter.Fill(this.db_KasirKSDataSet.Tb_Penjualan);
            this.tb_ProdukTableAdapter.Fill(this.db_KasirKSDataSet.Tb_Produk);

            Box_Diskon.Text = "0";
        }
        private void SetupTempTable()
        {
            TempDetailJoin.Clear();
            TempDetailJoin.Columns.Clear();

            TempDetailJoin.Columns.Add("ID_Detail", typeof(long));
            TempDetailJoin.Columns.Add("Nama_Anggota", typeof(string));
            TempDetailJoin.Columns.Add("Kode_Produk", typeof(string));
            TempDetailJoin.Columns.Add("Nama_Produk", typeof(string));
            TempDetailJoin.Columns.Add("Kuantitas", typeof(string));
            TempDetailJoin.Columns.Add("Harga", typeof(decimal));
            TempDetailJoin.Columns.Add("Jumlah_Beli", typeof(long));
            TempDetailJoin.Columns.Add("Diskon", typeof(string));
            TempDetailJoin.Columns.Add("Sub_Total", typeof(decimal));

            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.DataSource = TempDetailJoin;
        }
        private void SetupComboBox()
        {
            comboBox1.Items.Clear();
            comboBox2.Items.Clear();
            KolomMap.Clear();

            // ComboBox kolom
            comboBox1.Items.Add("ID Detail");
            comboBox1.Items.Add("Nama Anggota");
            comboBox1.Items.Add("Kode Produk");
            comboBox1.Items.Add("Nama Produk");
            comboBox1.Items.Add("Kuantitas");
            comboBox1.Items.Add("Harga");
            comboBox1.Items.Add("Jumlah Beli");
            comboBox1.Items.Add("Diskon");
            comboBox1.Items.Add("Sub Total");

            comboBox1.SelectedIndex = 0;

            // ComboBox sorting
            comboBox2.Items.Add("Ascending");
            comboBox2.Items.Add("Descending");
            comboBox2.SelectedIndex = 0;

            // Mapping kolom tampilan → kolom DataTable
            KolomMap.Add("ID Detail", "ID_Detail");
            KolomMap.Add("Nama Anggota", "Nama_Anggota");
            KolomMap.Add("Kode Produk", "Kode_Produk");
            KolomMap.Add("Nama Produk", "Nama_Produk");
            KolomMap.Add("Kuantitas", "Kuantitas");
            KolomMap.Add("Harga", "Harga");
            KolomMap.Add("Jumlah Beli", "Jumlah_Beli");
            KolomMap.Add("Diskon", "Diskon");
            KolomMap.Add("Sub Total", "Sub_Total");
        }

        // =============================
        // 🔹 EVENT
        // =============================
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            ResetFormKasir();

            // Reset tanggal ke hari ini
            Box_Tanggal.Text = DateTime.Now.ToString("yyyy-MM-dd");
        }
        private void btnPelangganUmum_Click(object sender, EventArgs e)
        {
            Box_IdAnggota.Text = "0";
            Box_NamaAnggota.Text = "Pelanggan Umum";
        }
        private void btnListAnggota_Click(object sender, EventArgs e)
        {
            Form_List_Anggota ListAnggota = new Form_List_Anggota(this);
            ListAnggota.Show();
        }
        private void btnListProduk_Click(object sender, EventArgs e)
        {
            Form_List_Produk ListProduk = new Form_List_Produk(this);

            ListProduk.Show();
            Box_IdProduk.Clear();
            Box_KodeProduk.Clear();
            Box_Kuantitas.Clear();
            Box_NamaProduk.Clear();
            Box_HargaProduk.Clear();
            Box_Kuantitas.Clear();
            Box_StokProduk.Clear();

            Box_JumlahBeli.Clear();
            Box_Diskon.Text = "0";
            Box_SubTotal.Clear();
        }
        private void Box_JumlahBeli_TextChanged(object sender, EventArgs e)
        {
            decimal JumlahBeli = 0;
            decimal HargaSatuan = 0;

            decimal.TryParse(Box_JumlahBeli.Text, out JumlahBeli);
            decimal.TryParse(Box_HargaProduk.Text, out HargaSatuan);

            // Hitung subtotal asli (sebelum diskon)
            decimal SubTotal = JumlahBeli * HargaSatuan;

            // Simpan subtotal asli ke Tag agar diskon selalu dihitung dari sini
            Box_SubTotal.Tag = SubTotal;

            // Tampilkan subtotal (format rapi)
            Box_SubTotal.Text = SubTotal.ToString("N2");

            // Aktifkan/Nonaktifkan diskon sesuai ada jumlah beli
            Box_Diskon.ReadOnly = string.IsNullOrWhiteSpace(Box_JumlahBeli.Text);
        }
        private void Box_Diskon_TextChanged(object sender, EventArgs e)
        {
            // Ambil angka saja dari textbox diskon (boleh kosong)
            string angkaDiskon = new string((Box_Diskon.Text ?? "")
                .Where(char.IsDigit)
                .ToArray());

            // Jika user menghapus semua teks → diskon dianggap tidak ada
            if (string.IsNullOrEmpty(angkaDiskon))
            {
                // Kembalikan subtotal ke nilai asli
                if (Box_SubTotal.Tag != null)
                    Box_SubTotal.Text = Convert.ToDecimal(Box_SubTotal.Tag).ToString("N2");

                // Biarkan Box_Diskon benar-benar kosong
                Box_Diskon.TextChanged -= Box_Diskon_TextChanged;
                Box_Diskon.Text = "";
                Box_Diskon.SelectionStart = 0;
                Box_Diskon.TextChanged += Box_Diskon_TextChanged;

                return; // Stop di sini
            }

            // Hilangkan nol di depan agar tidak jadi "070"
            angkaDiskon = angkaDiskon.TrimStart('0');
            if (string.IsNullOrEmpty(angkaDiskon))
                angkaDiskon = "0";

            // Ambil subtotal asli dari Tag (yang belum kena diskon)
            decimal subtotalAsli = 0m;
            if (Box_SubTotal.Tag != null)
                subtotalAsli = Convert.ToDecimal(Box_SubTotal.Tag);
            else
                decimal.TryParse(Box_SubTotal.Text, out subtotalAsli);

            if (subtotalAsli <= 0) // kalau belum ada nilai subtotal
            {
                Box_SubTotal.Text = "0.00";
                return;
            }

            // Konversi persen diskon
            decimal persenDiskon = 0m;
            decimal.TryParse(angkaDiskon, out persenDiskon);

            // Jika diskon = 0 → tidak ada diskon → kembalikan subtotal asli
            if (persenDiskon <= 0m)
            {
                Box_SubTotal.Text = subtotalAsli.ToString("N2");

                Box_Diskon.TextChanged -= Box_Diskon_TextChanged;
                Box_Diskon.Text = angkaDiskon;
                Box_Diskon.SelectionStart = Box_Diskon.Text.Length;
                Box_Diskon.TextChanged += Box_Diskon_TextChanged;

                return;
            }

            // Hitung subtotal setelah diskon
            decimal totalDiskon = subtotalAsli * (persenDiskon / 100m);
            decimal subtotalSetelahDiskon = subtotalAsli - totalDiskon;

            // Tampilkan subtotal hasil diskon
            Box_SubTotal.Text = subtotalSetelahDiskon.ToString("N2");

            // Update textbox diskon agar hanya tampil ANGKA tanpa 0 depan
            Box_Diskon.TextChanged -= Box_Diskon_TextChanged;
            Box_Diskon.Text = angkaDiskon;
            Box_Diskon.SelectionStart = Box_Diskon.Text.Length;
            Box_Diskon.TextChanged += Box_Diskon_TextChanged;
        }
        private void btnTambahkan_Click(object sender, EventArgs e)
        {
            // =============================
            // 1. VALIDASI WAJIB DIISI
            // =============================
            if (string.IsNullOrWhiteSpace(Box_IdProduk.Text))
            {
                MessageBox.Show("ID Produk wajib diisi!", "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Box_IdProduk.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(Box_NamaAnggota.Text))
            {
                MessageBox.Show("Nama Anggota wajib diisi!", "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Box_NamaAnggota.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(Box_KodeProduk.Text))
            {
                MessageBox.Show("Kode Produk wajib diisi!", "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Box_KodeProduk.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(Box_NamaProduk.Text))
            {
                MessageBox.Show("Nama Produk wajib diisi!", "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Box_NamaProduk.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(Box_Kuantitas.Text))
            {
                MessageBox.Show("Kuantitas wajib diisi!", "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Box_Kuantitas.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(Box_HargaProduk.Text))
            {
                MessageBox.Show("Harga Produk wajib diisi!", "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Box_HargaProduk.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(Box_JumlahBeli.Text))
            {
                MessageBox.Show("Jumlah Beli wajib diisi!", "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Box_JumlahBeli.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(Box_StokProduk.Text))
            {
                MessageBox.Show("Stok Produk wajib diisi!", "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Box_StokProduk.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(Box_Diskon.Text))
            {
                MessageBox.Show("Diskon wajib diisi! Isi 0 jika tidak ada diskon.", "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Box_Diskon.Focus();
                return;
            }

            // =============================
            // 2. VALIDASI ANGKA
            // =============================
            decimal JumlahBeli;
            decimal Stok;
            decimal Harga;

            if (!decimal.TryParse(Box_JumlahBeli.Text, out JumlahBeli))
            {
                MessageBox.Show("Jumlah Beli harus berupa angka!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Box_JumlahBeli.Focus();
                return;
            }

            if (!decimal.TryParse(Box_StokProduk.Text, out Stok))
            {
                MessageBox.Show("Stok Produk harus berupa angka!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Box_StokProduk.Focus();
                return;
            }

            if (!decimal.TryParse(Box_HargaProduk.Text, out Harga))
            {
                MessageBox.Show("Harga Produk harus berupa angka!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Box_HargaProduk.Focus();
                return;
            }

            // ===== VALIDASI STOK =====
            if (JumlahBeli <= 0)
            {
                MessageBox.Show("Jumlah beli tidak boleh nol!", "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (JumlahBeli > Stok)
            {
                MessageBox.Show("Stok produk tidak mencukupi!", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // =============================
            // 3. UPDATE STOK SEMENTARA
            // =============================
            long IdProduk = Convert.ToInt64(Box_IdProduk.Text);

            if (!StokSementara.ContainsKey(IdProduk))
                StokSementara[IdProduk] = (long)Stok;

            long stokBaru = (long)(Stok - JumlahBeli);
            tb_ProdukTableAdapter.UpdateStok(stokBaru, IdProduk);
            Box_StokProduk.Text = stokBaru.ToString();

            // =============================
            // 4. AMBIL DATA
            // =============================
            long ID_Detail = TempDetailJoin.Rows.Count + 1;

            string NamaAnggota = Box_NamaAnggota.Text;
            string No_Produk = Box_KodeProduk.Text;
            string NamaProduk = Box_NamaProduk.Text;
            string Kuantitas = Box_Kuantitas.Text;
            int Jumlah = (int)JumlahBeli;

            // ====== DISKON ======
            string DiskonText = Box_Diskon.Text;
            string AngkaDiskon = new string(DiskonText.Where(char.IsDigit).ToArray());
            if (AngkaDiskon == "") AngkaDiskon = "0";

            decimal PersenDiskon = Convert.ToDecimal(AngkaDiskon);

            decimal SubTotalSebelumDiskon = Harga * Jumlah;
            decimal TotalDiskon = SubTotalSebelumDiskon * (PersenDiskon / 100);
            decimal SubTotalSetelahDiskon = SubTotalSebelumDiskon - TotalDiskon;

            DiskonText = AngkaDiskon + "%";

            // =============================
            // 5. MASUKKAN KE TABEL TEMP
            // =============================
            TempDetailJoin.Rows.Add(
                ID_Detail,
                NamaAnggota,
                No_Produk,
                NamaProduk,
                Kuantitas,
                Harga,
                Jumlah,
                DiskonText,
                SubTotalSetelahDiskon
            );

            // =============================
            // 6. UPDATE GRAND TOTAL
            // =============================
            decimal grandTotalLama = 0, grandBanyakLama = 0;

            if (!string.IsNullOrEmpty(GrandTotal.Text))
            {
                string angka = new string(GrandTotal.Text.Where(char.IsDigit).ToArray());
                decimal.TryParse(angka, out grandTotalLama);
            }

            if (!string.IsNullOrEmpty(GrandBanyak.Text))
                decimal.TryParse(GrandBanyak.Text, out grandBanyakLama);

            decimal grandTotalBaru = grandTotalLama + SubTotalSetelahDiskon;
            decimal grandBanyakBaru = grandBanyakLama + Jumlah;

            GrandTotal.Text = "Rp" + grandTotalBaru.ToString("N0");
            GrandBanyak.Text = grandBanyakBaru.ToString();

            // =============================
            // 7. TAMPILKAN DAN SORT DATA
            // =============================
            dataGridView1.DataSource = TempDetailJoin;
            LakukanSorting();  // ⬅ WAJIB AGAR DATA BARU IKUT SORTING
        }
        private void Box_Bayar_TextChanged(object sender, EventArgs e)
        {
            decimal bayar = 0;
            decimal grand = 0;

            // ===============================
            // 1. KONVERSI NILAI BAYAR
            // ===============================
            decimal.TryParse(Box_Bayar.Text, out bayar);

            // ===============================
            // 2. HAPUS "Rp", titik, koma, spasi
            // ===============================
            string cleanedGrand = new string(
                GrandTotal.Text
                .Where(ch => char.IsDigit(ch) || ch == '.' || ch == ',')
                .ToArray());

            // Coba parse decimal Indonesia dan Invariant
            if (!decimal.TryParse(cleanedGrand, out grand))
            {
                decimal.TryParse(cleanedGrand,
                    System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture,
                    out grand);
            }

            // ===============================
            // 3. HITUNG KEMBALIAN
            // ===============================
            decimal kembalian = bayar - grand;

            // ===============================
            // 4. TAMPILKAN KEMBALIAN (
            // ===============================
            Box_Kembalian.Text = kembalian.ToString("N0");
        }
        private void btnBayar_Click(object sender, EventArgs e)
        {
            try
            {
                // =============================
                // 1. BERSIHKAN GRAND TOTAL
                // =============================
                string teksGrand = GrandTotal.Text;

                // hapus huruf, spasi, Rp, dll
                string cleanedGrand = "";
                for (int i = 0; i < teksGrand.Length; i++)
                {
                    char ch = teksGrand[i];
                    if (char.IsDigit(ch) || ch == '.' || ch == ',')
                    {
                        cleanedGrand += ch;
                    }
                }

                decimal grandTotal = 0;

                // Coba parse dengan Culture Indonesia (1.234,56)
                try
                {
                    grandTotal = Convert.ToDecimal(cleanedGrand,
                        System.Globalization.CultureInfo.GetCultureInfo("id-ID"));
                }
                catch
                {
                    // fallback jika gagal
                    try
                    {
                        grandTotal = Convert.ToDecimal(cleanedGrand,
                            System.Globalization.CultureInfo.InvariantCulture);
                    }
                    catch
                    {
                        grandTotal = 0;
                    }
                }

                // =============================
                // 2. VALIDASI PEMBAYARAN
                // =============================
                if (string.IsNullOrEmpty(Box_Bayar.Text))
                {
                    MessageBox.Show("Masukkan nominal pembayaran terlebih dahulu!",
                        "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                decimal bayar = 0;
                try
                {
                    bayar = Convert.ToDecimal(Box_Bayar.Text,
                        System.Globalization.CultureInfo.GetCultureInfo("id-ID"));
                }
                catch
                {
                    bayar = Convert.ToDecimal(Box_Bayar.Text);
                }

                decimal selisih = bayar - grandTotal;

                // =============================
                // 3. LOGIKA TRANSAKSI
                // =============================

                if (selisih > 0)
                {
                    MessageBox.Show(
                        string.Format("Transaksi berhasil! Uang lebih sebesar Rp {0:N0}.", selisih),
                        "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    SimpanTransaksi(bayar, 0);
                }
                else if (selisih == 0)
                {
                    MessageBox.Show("Transaksi pas! Terima kasih.",
                        "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    SimpanTransaksi(bayar, 0);
                }
                else
                {
                    decimal hutang = Math.Abs(selisih);

                    DialogResult result = MessageBox.Show(
                        string.Format("Pembayaran kurang Rp {0:N0}. Tambahkan sebagai hutang?", hutang),
                        "Konfirmasi Hutang",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question
                    );

                    if (result == DialogResult.Yes)
                    {
                        MessageBox.Show(
                            string.Format("Transaksi tetap disimpan.\nNominal hutang: Rp {0:N0}", hutang),
                            "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        SimpanTransaksi(bayar, hutang);
                    }
                    else
                    {
                        MessageBox.Show(
                            "Transaksi dibatalkan karena pembayaran tidak mencukupi.",
                            "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Terjadi kesalahan: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            TransaksiSudahDisimpan = true;
            StokSementara.Clear();
            TempDetailJoin.Clear();
        }
        private void btnBayarLangsung_Click(object sender, EventArgs e)
        {
            try
            {
                string teksGrand = GrandTotal.Text;

                // =============================
                // 1. BERSIHKAN TEKS GRAND TOTAL
                // =============================
                string onlyNumber = "";
                for (int i = 0; i < teksGrand.Length; i++)
                {
                    char ch = teksGrand[i];
                    if (char.IsDigit(ch) || ch == '.' || ch == ',')
                    {
                        onlyNumber += ch;
                    }
                }

                decimal grandTotal = 0;

                // parse gaya Indonesia (1.234,56)
                try
                {
                    grandTotal = Convert.ToDecimal(onlyNumber,
                        System.Globalization.CultureInfo.GetCultureInfo("id-ID"));
                }
                catch
                {
                    // fallback
                    try
                    {
                        grandTotal = Convert.ToDecimal(onlyNumber,
                            System.Globalization.CultureInfo.InvariantCulture);
                    }
                    catch
                    {
                        grandTotal = 0;
                    }
                }

                // =============================
                // 2. BAYAR LANGSUNG = PAS
                // =============================
                Box_Bayar.Text = grandTotal.ToString("N0"); // format angka rapi
                Box_Kembalian.Text = "0";

                MessageBox.Show("Transaksi langsung (bayar pas).",
                    "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information);

                SimpanTransaksi(grandTotal, 0);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Terjadi kesalahan: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            TransaksiSudahDisimpan = true;
            StokSementara.Clear();
            TempDetailJoin.Clear();
        }
        private void hapusItemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Pilih item yang ingin dihapus terlebih dahulu!",
                        "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (MessageBox.Show("Apakah Anda yakin ingin menghapus item ini?",
                    "Konfirmasi Hapus", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                    != DialogResult.Yes) return;

                DataGridViewRow row = dataGridView1.SelectedRows[0];

                // ==================================================================
                // 1. DAPATKAN INDEX KOLUM BERDASARKAN DATAPROPERTYNAME ASLI DATABASE
                // ==================================================================
                int colJumlah = -1;
                int colSubTotal = -1;

                for (int i = 0; i < dataGridView1.Columns.Count; i++)
                {
                    string dp = (dataGridView1.Columns[i].DataPropertyName ?? "").ToLower();

                    if (dp == "jumlah_beli")
                        colJumlah = i;

                    if (dp == "sub_total")
                        colSubTotal = i;
                }

                if (colJumlah == -1 || colSubTotal == -1)
                {
                    MessageBox.Show("Kolom Jumlah_Beli atau Sub_Total tidak ditemukan!",
                        "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // ==================================================================
                // 2. AMBIL NILAI JUMLAH BELI
                // ==================================================================
                long jumlahBeli;
                if (!long.TryParse(row.Cells[colJumlah].Value.ToString(), out jumlahBeli))
                {
                    MessageBox.Show("Nilai 'Jumlah_Beli' tidak valid!",
                        "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // ==================================================================
                // 3. AMBIL SUBTOTAL
                // ==================================================================
                decimal subTotal;
                string cleaned = new string(row.Cells[colSubTotal].Value
                    .ToString()
                    .Where(ch => char.IsDigit(ch) || ch == ',' || ch == '.')
                    .ToArray());

                if (!decimal.TryParse(cleaned, out subTotal))
                    decimal.TryParse(cleaned,
                        System.Globalization.NumberStyles.Any,
                        System.Globalization.CultureInfo.InvariantCulture,
                        out subTotal);

                // ==================================================================
                // 4. AMBIL ID PRODUK
                // ==================================================================
                long idProduk;
                if (!long.TryParse(Box_IdProduk.Text, out idProduk))
                {
                    MessageBox.Show("Box_IdProduk kosong atau tidak valid.",
                        "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // ==================================================================
                // 5. KEMBALIKAN STOK
                // ==================================================================
                long stokLama = tb_ProdukTableAdapter.JumlahStok(idProduk).GetValueOrDefault();
                long stokBaru = stokLama + jumlahBeli;

                tb_ProdukTableAdapter.UpdateStok(stokBaru, idProduk);

                if (Box_IdProduk.Text == idProduk.ToString())
                    Box_StokProduk.Text = stokBaru.ToString();

                // ==================================================================
                // 6. UPDATE GRANDTOTAL & ITEMTOTAL
                // ==================================================================
                string cleanedGrand = new string(GrandTotal.Text
                    .Where(ch => char.IsDigit(ch) || ch == ',' || ch == '.')
                    .ToArray());

                decimal gt = 0;
                decimal.TryParse(cleanedGrand, out gt);

                decimal gtBaru = gt - subTotal;
                if (gtBaru < 0) gtBaru = 0;

                GrandTotal.Text = "Rp" + gtBaru.ToString("N0");

                long gb = 0;
                long.TryParse(GrandBanyak.Text, out gb);
                long gbBaru = gb - jumlahBeli;
                if (gbBaru < 0) gbBaru = 0;

                GrandBanyak.Text = gbBaru.ToString();

                // ==================================================================
                // 7. HAPUS BARIS DARI TEMPDETAILJOIN
                // ==================================================================
                int idx = row.Index;
                if (idx >= 0 && idx < TempDetailJoin.Rows.Count)
                    TempDetailJoin.Rows.RemoveAt(idx);

                // ==================================================================
                // 🔥 8. RE-NUMBER ID_DETAIL (INI BAGIAN PALING PENTING)
                // ==================================================================
                // ASUMSI KOLOM PERTAMA TempDetailJoin ADALAH ID_DETAIL
                for (int i = 0; i < TempDetailJoin.Rows.Count; i++)
                {
                    TempDetailJoin.Rows[i][0] = i + 1; // ID di-reset sesuai urutan baru
                }

                dataGridView1.DataSource = null;
                dataGridView1.DataSource = TempDetailJoin;

                MessageBox.Show("Item berhasil dihapus dan ID ditata ulang.",
                    "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Terjadi kesalahan: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            LakukanSorting();
        }
        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            LakukanSorting();
        }
        private void textBox9_TextChanged(object sender, EventArgs e)
        {
            string filter = textBox9.Text.Trim();

            // Jika kosong → tampilkan semua data
            if (string.IsNullOrEmpty(filter))
            {
                dataGridView1.DataSource = TempDetailJoin;
                LakukanSorting();
                return;
            }

            string pilihan = comboBox1.SelectedItem.ToString();
            string modeSort = comboBox2.SelectedItem != null ? comboBox2.SelectedItem.ToString() : "Ascending";

            bool useLower = (modeSort == "Descending");

            var data = TempDetailJoin.AsEnumerable();

            IEnumerable<DataRow> query = null;

            Func<string, string> normalize = (s) =>
            {
                if (s == null) return "";
                return useLower ? s.ToLower() : s;
            };

            string f = normalize(filter);

            switch (pilihan)
            {
                case "ID Detail":
                    query = data.Where(r => normalize(r["ID_Detail"].ToString()).Contains(f));
                    break;

                case "Nama Anggota":
                    query = data.Where(r => normalize(r["Nama_Anggota"].ToString()).Contains(f));
                    break;

                case "Kode Produk":
                    query = data.Where(r => normalize(r["Kode_Produk"].ToString()).Contains(f));
                    break;

                case "Nama Produk":
                    query = data.Where(r => normalize(r["Nama_Produk"].ToString()).Contains(f));
                    break;

                case "Kuantitas":
                    query = data.Where(r => normalize(r["Kuantitas"].ToString()).Contains(f));
                    break;

                case "Harga":
                    query = data.Where(r => normalize(r["Harga"].ToString()).Contains(f));
                    break;

                case "Jumlah Beli":
                    query = data.Where(r => normalize(r["Jumlah_Beli"].ToString()).Contains(f));
                    break;

                case "Diskon":
                    query = data.Where(r => normalize(r["Diskon"].ToString()).Contains(f));
                    break;

                case "Sub Total":
                    query = data.Where(r => normalize(r["Sub_Total"].ToString()).Contains(f));
                    break;

                default:
                    query = data;
                    break;
            }

            DataTable hasil;

            if (query.Any())
                hasil = query.CopyToDataTable();
            else
                hasil = TempDetailJoin.Clone(); // tabel kosong

            dataGridView1.DataSource = hasil;

            // Sorting ulang
            LakukanSorting();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            textBox9.Text = "";
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Box_IdAnggota.Text = "";
            Box_NamaAnggota.Text = "";
        }

        // =============================
        // 🔹 TRANSAKSI CORE
        // =============================
        private void SimpanTransaksi(decimal bayar, decimal hutang)
        {
            try
            {
                if (TempDetailJoin.Rows.Count == 0)
                {
                    MessageBox.Show("Tidak ada produk dalam transaksi!",
                        "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // =============================
                // 1. BERSIHKAN TEKS GRANDTOTAL
                // =============================
                string teksGrand = GrandTotal.Text;
                string cleanedGrand = "";

                // Ambil hanya digit, titik, koma
                for (int i = 0; i < teksGrand.Length; i++)
                {
                    char ch = teksGrand[i];
                    if (char.IsDigit(ch) || ch == '.' || ch == ',')
                    {
                        cleanedGrand += ch;
                    }
                }

                decimal grandTotal = 0;

                // Parsing aman format Indonesia
                try
                {
                    grandTotal = Convert.ToDecimal(cleanedGrand,
                        System.Globalization.CultureInfo.GetCultureInfo("id-ID"));
                }
                catch
                {
                    try
                    {
                        grandTotal = Convert.ToDecimal(cleanedGrand,
                            System.Globalization.CultureInfo.InvariantCulture);
                    }
                    catch
                    {
                        grandTotal = 0;
                    }
                }

                // =============================
                // 2. AUTO NUMBER
                // =============================
                Nourut = Convert.ToInt64(tb_PenjualanTableAdapter.AutoNumber().GetValueOrDefault()) + 1;

                // =============================
                // 3. SIMPAN PENJUALAN
                // =============================
                tb_PenjualanTableAdapter.TambahPenjualan(
                    Nourut,
                    Box_Tanggal.Value.ToString("yyyy-MM-dd"),
                    bayar,
                    hutang,
                    Convert.ToInt64(Box_IdAnggota.Text)
                );

                // =============================
                // 4. SIMPAN DETAIL PENJUALAN
                // =============================
                foreach (DataRow row in TempDetailJoin.Rows)
                {
                    AutoDetailUrut = Convert.ToInt64(tb_DetailPenjualanTableAdapter.AutoNumber().GetValueOrDefault()) + 1;

                    long IdProduk = Convert.ToInt64(Box_IdProduk.Text);
                    long JumlahBeli = Convert.ToInt64(row["Jumlah_Beli"]);
                    string Diskon = Convert.ToString(row["Diskon"]);
                    decimal SubTotal = Convert.ToDecimal(row["Sub_Total"]);

                    tb_DetailPenjualanTableAdapter.TambahDetail(
                        AutoDetailUrut,
                        Nourut,
                        IdProduk,
                        JumlahBeli,
                        Diskon,
                        SubTotal
                    );
                }

                // =============================
                // 5. RESET UI 
                // =============================
                TransaksiSudahDisimpan = true;
                StokSementara.Clear();
                TempDetailJoin.Clear();
                ResetFormKasir();

                MessageBox.Show("Transaksi berhasil disimpan!",
                    "Sukses", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Terjadi Kesalahan Saat Menyimpan: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public bool AdaTransaksiBerjalan()
        {
            return TempDetailJoin.Rows.Count > 0;
        }
        public void BatalkanTransaksi()
        {
            foreach (var item in StokSementara)
            {
                long idProduk = item.Key;
                long stokAsli = item.Value;
                tb_ProdukTableAdapter.UpdateStok(stokAsli, idProduk);
            }

            StokSementara.Clear();
            TempDetailJoin.Clear();
            ResetFormKasir();
        }
        private void LakukanSorting()
        {
            try
            {
                // Cek combobox harus terpilih
                if (comboBox1.SelectedItem == null || comboBox2.SelectedItem == null)
                    return;

                string pilihanKolom = comboBox1.SelectedItem.ToString();
                string mode = comboBox2.SelectedItem.ToString();

                // Jika kolom tidak terdaftar di mapping, stop
                if (!KolomMap.ContainsKey(pilihanKolom))
                    return;

                string kolom = KolomMap[pilihanKolom];

                // Ambil data yang sedang TAMPIL (HASIL FILTER)
                DataTable sumber;

                if (dataGridView1.DataSource is DataTable)
                    sumber = (DataTable)dataGridView1.DataSource;
                else
                    sumber = TempDetailJoin;

                // Jika tabel kosong → jangan sorting
                if (sumber.Rows.Count == 0)
                    return;

                var rows = sumber.AsEnumerable().ToList();

                bool kolomAngka =
                    sumber.Columns[kolom].DataType == typeof(int) ||
                    sumber.Columns[kolom].DataType == typeof(long) ||
                    sumber.Columns[kolom].DataType == typeof(decimal);

                List<DataRow> sortedRows;

                if (kolomAngka)
                {
                    if (mode == "Descending")
                    {
                        sortedRows = rows
                            .OrderByDescending(r =>
                            {
                                decimal v;
                                decimal.TryParse(r[kolom].ToString(), out v);
                                return v;
                            })
                            .ToList();
                    }
                    else
                    {
                        sortedRows = rows
                            .OrderBy(r =>
                            {
                                decimal v;
                                decimal.TryParse(r[kolom].ToString(), out v);
                                return v;
                            })
                            .ToList();
                    }
                }
                else
                {
                    if (mode == "Descending")
                    {
                        sortedRows = rows
                            .OrderByDescending(r => r[kolom].ToString())
                            .ToList();
                    }
                    else
                    {
                        sortedRows = rows
                            .OrderBy(r => r[kolom].ToString())
                            .ToList();
                    }
                }

                // Penting! Jika tidak ada hasil, DataGridView harus tetap bisa menampilkan tabel kosong
                if (sortedRows.Count > 0)
                    dataGridView1.DataSource = sortedRows.CopyToDataTable();
                else
                    dataGridView1.DataSource = sumber.Clone(); // tabel kosong
            }
            catch
            {
                // Jangan tampilkan pesan error agar user tidak terganggu
            }
        }
        private void UcKasir_ControlRemoved(object sender, ControlEventArgs e) 
        { 

        }
    }
}
