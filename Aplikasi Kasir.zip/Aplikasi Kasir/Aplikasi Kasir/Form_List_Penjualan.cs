﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aplikasi_Kasir
{
    public partial class Form_List_Penjualan : Form
    {
        public Form_List_Penjualan()
        {
            InitializeComponent();
        }
    }
}
