﻿namespace Aplikasi_Kasir
{
    partial class UcDashboard
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.labelTotalJumlahBeli = new System.Windows.Forms.Label();
            this.labelTotalSemuaHarga = new System.Windows.Forms.Label();
            this.labelTotalCash = new System.Windows.Forms.Label();
            this.labelTotalHutang = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.labelTotalProduk = new System.Windows.Forms.Label();
            this.labelBatasTanggal = new System.Windows.Forms.Label();
            this.labelTotalAnggota = new System.Windows.Forms.Label();
            this.labelTotalPenjualan = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnTotalDataLabel = new System.Windows.Forms.Button();
            this.btnDiagramChart = new System.Windows.Forms.Button();
            this.tb_PenjualanBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.db_KasirKSDataSet = new Aplikasi_Kasir.Db_KasirKSDataSet();
            this.tb_DetailPenjualanBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tb_AnggotaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tb_ProdukBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.panel5 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Box_Tanggal2 = new System.Windows.Forms.DateTimePicker();
            this.Box_Tanggal1 = new System.Windows.Forms.DateTimePicker();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.tb_AnggotaTableAdapter = new Aplikasi_Kasir.Db_KasirKSDataSetTableAdapters.Tb_AnggotaTableAdapter();
            this.tableAdapterManager = new Aplikasi_Kasir.Db_KasirKSDataSetTableAdapters.TableAdapterManager();
            this.tb_DetailPenjualanTableAdapter = new Aplikasi_Kasir.Db_KasirKSDataSetTableAdapters.Tb_DetailPenjualanTableAdapter();
            this.tb_PenjualanTableAdapter = new Aplikasi_Kasir.Db_KasirKSDataSetTableAdapters.Tb_PenjualanTableAdapter();
            this.tb_ProdukTableAdapter = new Aplikasi_Kasir.Db_KasirKSDataSetTableAdapters.Tb_ProdukTableAdapter();
            this.btnUp = new System.Windows.Forms.Button();
            this.btnRefreshKotakTeks = new System.Windows.Forms.Button();
            this.btnRefreshAnggota = new System.Windows.Forms.Button();
            this.btnRefreshTanggal = new System.Windows.Forms.Button();
            this.labelNotif = new System.Windows.Forms.Label();
            this.checkBoxTanggal = new Guna.UI2.WinForms.Guna2CheckBox();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tb_PenjualanBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.db_KasirKSDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tb_DetailPenjualanBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tb_AnggotaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tb_ProdukBindingSource)).BeginInit();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.SteelBlue;
            this.panel6.Controls.Add(this.btnUp);
            this.panel6.Location = new System.Drawing.Point(880, 3);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(565, 230);
            this.panel6.TabIndex = 113;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.SteelBlue;
            this.panel7.Controls.Add(this.labelTotalJumlahBeli);
            this.panel7.Controls.Add(this.labelTotalSemuaHarga);
            this.panel7.Controls.Add(this.labelTotalCash);
            this.panel7.Controls.Add(this.labelTotalHutang);
            this.panel7.Location = new System.Drawing.Point(514, 239);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(931, 159);
            this.panel7.TabIndex = 116;
            // 
            // labelTotalJumlahBeli
            // 
            this.labelTotalJumlahBeli.AutoSize = true;
            this.labelTotalJumlahBeli.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTotalJumlahBeli.Location = new System.Drawing.Point(11, 6);
            this.labelTotalJumlahBeli.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelTotalJumlahBeli.MaximumSize = new System.Drawing.Size(801, 0);
            this.labelTotalJumlahBeli.Name = "labelTotalJumlahBeli";
            this.labelTotalJumlahBeli.Size = new System.Drawing.Size(210, 28);
            this.labelTotalJumlahBeli.TabIndex = 90;
            this.labelTotalJumlahBeli.Text = "🛒 Total Jumlah Beli :";
            // 
            // labelTotalSemuaHarga
            // 
            this.labelTotalSemuaHarga.AutoSize = true;
            this.labelTotalSemuaHarga.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTotalSemuaHarga.Location = new System.Drawing.Point(11, 39);
            this.labelTotalSemuaHarga.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelTotalSemuaHarga.MaximumSize = new System.Drawing.Size(801, 0);
            this.labelTotalSemuaHarga.Name = "labelTotalSemuaHarga";
            this.labelTotalSemuaHarga.Size = new System.Drawing.Size(228, 28);
            this.labelTotalSemuaHarga.TabIndex = 91;
            this.labelTotalSemuaHarga.Text = "💰 Total Semua Harga :";
            // 
            // labelTotalCash
            // 
            this.labelTotalCash.AutoSize = true;
            this.labelTotalCash.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTotalCash.Location = new System.Drawing.Point(11, 72);
            this.labelTotalCash.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelTotalCash.MaximumSize = new System.Drawing.Size(801, 0);
            this.labelTotalCash.Name = "labelTotalCash";
            this.labelTotalCash.Size = new System.Drawing.Size(268, 28);
            this.labelTotalCash.TabIndex = 92;
            this.labelTotalCash.Text = "💲 Total Keseluruhan Cash :";
            // 
            // labelTotalHutang
            // 
            this.labelTotalHutang.AutoSize = true;
            this.labelTotalHutang.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTotalHutang.Location = new System.Drawing.Point(11, 105);
            this.labelTotalHutang.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelTotalHutang.MaximumSize = new System.Drawing.Size(801, 0);
            this.labelTotalHutang.Name = "labelTotalHutang";
            this.labelTotalHutang.Size = new System.Drawing.Size(293, 28);
            this.labelTotalHutang.TabIndex = 93;
            this.labelTotalHutang.Text = "💸 Total Keseluruhan Hutang :";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.SteelBlue;
            this.panel2.Controls.Add(this.labelTotalProduk);
            this.panel2.Controls.Add(this.labelBatasTanggal);
            this.panel2.Controls.Add(this.labelTotalAnggota);
            this.panel2.Controls.Add(this.labelTotalPenjualan);
            this.panel2.Location = new System.Drawing.Point(3, 239);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(505, 159);
            this.panel2.TabIndex = 115;
            // 
            // labelTotalProduk
            // 
            this.labelTotalProduk.AutoSize = true;
            this.labelTotalProduk.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTotalProduk.Location = new System.Drawing.Point(11, 120);
            this.labelTotalProduk.Name = "labelTotalProduk";
            this.labelTotalProduk.Size = new System.Drawing.Size(223, 28);
            this.labelTotalProduk.TabIndex = 94;
            this.labelTotalProduk.Text = "📦 Total Jenis Produk :";
            // 
            // labelBatasTanggal
            // 
            this.labelBatasTanggal.AutoSize = true;
            this.labelBatasTanggal.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBatasTanggal.Location = new System.Drawing.Point(11, 6);
            this.labelBatasTanggal.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelBatasTanggal.MaximumSize = new System.Drawing.Size(801, 0);
            this.labelBatasTanggal.Name = "labelBatasTanggal";
            this.labelBatasTanggal.Size = new System.Drawing.Size(208, 28);
            this.labelBatasTanggal.TabIndex = 73;
            this.labelBatasTanggal.Text = "📅 Rentang Tanggal :";
            // 
            // labelTotalAnggota
            // 
            this.labelTotalAnggota.AutoSize = true;
            this.labelTotalAnggota.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTotalAnggota.Location = new System.Drawing.Point(11, 54);
            this.labelTotalAnggota.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelTotalAnggota.MaximumSize = new System.Drawing.Size(801, 0);
            this.labelTotalAnggota.Name = "labelTotalAnggota";
            this.labelTotalAnggota.Size = new System.Drawing.Size(184, 28);
            this.labelTotalAnggota.TabIndex = 86;
            this.labelTotalAnggota.Text = "👥 Total Anggota :";
            // 
            // labelTotalPenjualan
            // 
            this.labelTotalPenjualan.AutoSize = true;
            this.labelTotalPenjualan.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTotalPenjualan.Location = new System.Drawing.Point(11, 87);
            this.labelTotalPenjualan.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelTotalPenjualan.MaximumSize = new System.Drawing.Size(801, 0);
            this.labelTotalPenjualan.Name = "labelTotalPenjualan";
            this.labelTotalPenjualan.Size = new System.Drawing.Size(194, 28);
            this.labelTotalPenjualan.TabIndex = 88;
            this.labelTotalPenjualan.Text = "💵 Total Penjualan :";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SteelBlue;
            this.panel1.Controls.Add(this.labelNotif);
            this.panel1.Controls.Add(this.btnTotalDataLabel);
            this.panel1.Controls.Add(this.btnDiagramChart);
            this.panel1.Location = new System.Drawing.Point(420, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(454, 230);
            this.panel1.TabIndex = 114;
            // 
            // btnTotalDataLabel
            // 
            this.btnTotalDataLabel.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnTotalDataLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTotalDataLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTotalDataLabel.ForeColor = System.Drawing.Color.White;
            this.btnTotalDataLabel.Location = new System.Drawing.Point(4, 16);
            this.btnTotalDataLabel.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnTotalDataLabel.Name = "btnTotalDataLabel";
            this.btnTotalDataLabel.Size = new System.Drawing.Size(298, 55);
            this.btnTotalDataLabel.TabIndex = 38;
            this.btnTotalDataLabel.Text = "📝 Tampilkan Total Data";
            this.btnTotalDataLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTotalDataLabel.UseVisualStyleBackColor = false;
            this.btnTotalDataLabel.Click += new System.EventHandler(this.btnTotalDataLabel_Click);
            // 
            // btnDiagramChart
            // 
            this.btnDiagramChart.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnDiagramChart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDiagramChart.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDiagramChart.ForeColor = System.Drawing.Color.White;
            this.btnDiagramChart.Location = new System.Drawing.Point(6, 88);
            this.btnDiagramChart.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnDiagramChart.Name = "btnDiagramChart";
            this.btnDiagramChart.Size = new System.Drawing.Size(298, 55);
            this.btnDiagramChart.TabIndex = 37;
            this.btnDiagramChart.Text = "📊 Tampilkan Diagram Chart";
            this.btnDiagramChart.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDiagramChart.UseVisualStyleBackColor = false;
            this.btnDiagramChart.Click += new System.EventHandler(this.btnDiagramChart_Click);
            // 
            // tb_PenjualanBindingSource
            // 
            this.tb_PenjualanBindingSource.DataMember = "Tb_Penjualan";
            this.tb_PenjualanBindingSource.DataSource = this.db_KasirKSDataSet;
            // 
            // db_KasirKSDataSet
            // 
            this.db_KasirKSDataSet.DataSetName = "Db_KasirKSDataSet";
            this.db_KasirKSDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tb_DetailPenjualanBindingSource
            // 
            this.tb_DetailPenjualanBindingSource.DataMember = "Tb_DetailPenjualan";
            this.tb_DetailPenjualanBindingSource.DataSource = this.db_KasirKSDataSet;
            // 
            // tb_AnggotaBindingSource
            // 
            this.tb_AnggotaBindingSource.DataMember = "Tb_Anggota";
            this.tb_AnggotaBindingSource.DataSource = this.db_KasirKSDataSet;
            // 
            // tb_ProdukBindingSource
            // 
            this.tb_ProdukBindingSource.DataMember = "Tb_Produk";
            this.tb_ProdukBindingSource.DataSource = this.db_KasirKSDataSet;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.SteelBlue;
            this.panel5.Controls.Add(this.btnRefreshKotakTeks);
            this.panel5.Controls.Add(this.checkBoxTanggal);
            this.panel5.Controls.Add(this.btnRefreshTanggal);
            this.panel5.Controls.Add(this.btnRefreshAnggota);
            this.panel5.Controls.Add(this.label9);
            this.panel5.Controls.Add(this.label4);
            this.panel5.Controls.Add(this.Box_Tanggal2);
            this.panel5.Controls.Add(this.Box_Tanggal1);
            this.panel5.Controls.Add(this.textBox7);
            this.panel5.Location = new System.Drawing.Point(3, 3);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(411, 230);
            this.panel5.TabIndex = 112;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(11, 82);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 28);
            this.label9.TabIndex = 58;
            this.label9.Text = "Akhir";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(11, 54);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 28);
            this.label4.TabIndex = 57;
            this.label4.Text = "Awal";
            // 
            // Box_Tanggal2
            // 
            this.Box_Tanggal2.Location = new System.Drawing.Point(73, 88);
            this.Box_Tanggal2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Box_Tanggal2.Name = "Box_Tanggal2";
            this.Box_Tanggal2.Size = new System.Drawing.Size(327, 22);
            this.Box_Tanggal2.TabIndex = 56;
            this.Box_Tanggal2.ValueChanged += new System.EventHandler(this.Box_Tanggal2_ValueChanged);
            // 
            // Box_Tanggal1
            // 
            this.Box_Tanggal1.Location = new System.Drawing.Point(73, 56);
            this.Box_Tanggal1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Box_Tanggal1.Name = "Box_Tanggal1";
            this.Box_Tanggal1.Size = new System.Drawing.Size(327, 22);
            this.Box_Tanggal1.TabIndex = 55;
            this.Box_Tanggal1.ValueChanged += new System.EventHandler(this.Box_Tanggal1_ValueChanged);
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox7.Location = new System.Drawing.Point(16, 14);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(241, 34);
            this.textBox7.TabIndex = 20;
            this.textBox7.TextChanged += new System.EventHandler(this.textBox7_TextChanged);
            // 
            // tb_AnggotaTableAdapter
            // 
            this.tb_AnggotaTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Tb_AnggotaTableAdapter = this.tb_AnggotaTableAdapter;
            this.tableAdapterManager.Tb_DetailPenjualanTableAdapter = this.tb_DetailPenjualanTableAdapter;
            this.tableAdapterManager.Tb_PenjualanTableAdapter = this.tb_PenjualanTableAdapter;
            this.tableAdapterManager.Tb_ProdukTableAdapter = this.tb_ProdukTableAdapter;
            this.tableAdapterManager.UpdateOrder = Aplikasi_Kasir.Db_KasirKSDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // tb_DetailPenjualanTableAdapter
            // 
            this.tb_DetailPenjualanTableAdapter.ClearBeforeFill = true;
            // 
            // tb_PenjualanTableAdapter
            // 
            this.tb_PenjualanTableAdapter.ClearBeforeFill = true;
            // 
            // tb_ProdukTableAdapter
            // 
            this.tb_ProdukTableAdapter.ClearBeforeFill = true;
            // 
            // btnUp
            // 
            this.btnUp.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnUp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUp.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUp.ForeColor = System.Drawing.Color.White;
            this.btnUp.Location = new System.Drawing.Point(26, 161);
            this.btnUp.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnUp.Name = "btnUp";
            this.btnUp.Size = new System.Drawing.Size(129, 55);
            this.btnUp.TabIndex = 117;
            this.btnUp.Text = "🔼";
            this.btnUp.UseVisualStyleBackColor = false;
            this.btnUp.Click += new System.EventHandler(this.btnUp_Click);
            // 
            // btnRefreshKotakTeks
            // 
            this.btnRefreshKotakTeks.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnRefreshKotakTeks.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRefreshKotakTeks.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefreshKotakTeks.ForeColor = System.Drawing.Color.White;
            this.btnRefreshKotakTeks.Location = new System.Drawing.Point(278, 134);
            this.btnRefreshKotakTeks.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnRefreshKotakTeks.Name = "btnRefreshKotakTeks";
            this.btnRefreshKotakTeks.Size = new System.Drawing.Size(129, 55);
            this.btnRefreshKotakTeks.TabIndex = 98;
            this.btnRefreshKotakTeks.Text = "♻️";
            this.btnRefreshKotakTeks.UseVisualStyleBackColor = false;
            this.btnRefreshKotakTeks.Click += new System.EventHandler(this.btnRefreshKotakTeks_Click);
            // 
            // btnRefreshAnggota
            // 
            this.btnRefreshAnggota.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnRefreshAnggota.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRefreshAnggota.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefreshAnggota.ForeColor = System.Drawing.Color.White;
            this.btnRefreshAnggota.Location = new System.Drawing.Point(4, 134);
            this.btnRefreshAnggota.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnRefreshAnggota.Name = "btnRefreshAnggota";
            this.btnRefreshAnggota.Size = new System.Drawing.Size(129, 55);
            this.btnRefreshAnggota.TabIndex = 97;
            this.btnRefreshAnggota.Text = " 🔄 / 👥";
            this.btnRefreshAnggota.UseVisualStyleBackColor = false;
            this.btnRefreshAnggota.Click += new System.EventHandler(this.btnRefreshAnggota_Click);
            // 
            // btnRefreshTanggal
            // 
            this.btnRefreshTanggal.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnRefreshTanggal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRefreshTanggal.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefreshTanggal.ForeColor = System.Drawing.Color.White;
            this.btnRefreshTanggal.Location = new System.Drawing.Point(141, 134);
            this.btnRefreshTanggal.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnRefreshTanggal.Name = "btnRefreshTanggal";
            this.btnRefreshTanggal.Size = new System.Drawing.Size(129, 55);
            this.btnRefreshTanggal.TabIndex = 95;
            this.btnRefreshTanggal.Text = "🔄 / 📅";
            this.btnRefreshTanggal.UseVisualStyleBackColor = false;
            this.btnRefreshTanggal.Click += new System.EventHandler(this.btnRefreshTanggal_Click);
            // 
            // labelNotif
            // 
            this.labelNotif.AutoSize = true;
            this.labelNotif.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNotif.Location = new System.Drawing.Point(18, 161);
            this.labelNotif.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelNotif.MaximumSize = new System.Drawing.Size(801, 0);
            this.labelNotif.Name = "labelNotif";
            this.labelNotif.Size = new System.Drawing.Size(58, 28);
            this.labelNotif.TabIndex = 94;
            this.labelNotif.Text = "Notif";
            // 
            // checkBoxTanggal
            // 
            this.checkBoxTanggal.AutoSize = true;
            this.checkBoxTanggal.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxTanggal.CheckedState.BorderRadius = 0;
            this.checkBoxTanggal.CheckedState.BorderThickness = 0;
            this.checkBoxTanggal.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.checkBoxTanggal.Location = new System.Drawing.Point(266, 22);
            this.checkBoxTanggal.Name = "checkBoxTanggal";
            this.checkBoxTanggal.Size = new System.Drawing.Size(134, 20);
            this.checkBoxTanggal.TabIndex = 59;
            this.checkBoxTanggal.Text = "guna2CheckBox1";
            this.checkBoxTanggal.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.checkBoxTanggal.UncheckedState.BorderRadius = 0;
            this.checkBoxTanggal.UncheckedState.BorderThickness = 0;
            this.checkBoxTanggal.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.checkBoxTanggal.CheckedChanged += new System.EventHandler(this.checkBoxTanggal_CheckedChanged);
            // 
            // UcDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel5);
            this.Name = "UcDashboard";
            this.Size = new System.Drawing.Size(1862, 2840);
            this.Load += new System.EventHandler(this.UcDashboard_Load);
            this.panel6.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tb_PenjualanBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.db_KasirKSDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tb_DetailPenjualanBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tb_AnggotaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tb_ProdukBindingSource)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        internal System.Windows.Forms.Label labelTotalJumlahBeli;
        internal System.Windows.Forms.Label labelTotalSemuaHarga;
        internal System.Windows.Forms.Label labelTotalCash;
        internal System.Windows.Forms.Label labelTotalHutang;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label labelTotalProduk;
        internal System.Windows.Forms.Label labelBatasTanggal;
        internal System.Windows.Forms.Label labelTotalAnggota;
        internal System.Windows.Forms.Label labelTotalPenjualan;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnTotalDataLabel;
        private System.Windows.Forms.Button btnDiagramChart;
        private System.Windows.Forms.BindingSource tb_PenjualanBindingSource;
        private Db_KasirKSDataSet db_KasirKSDataSet;
        private System.Windows.Forms.BindingSource tb_DetailPenjualanBindingSource;
        private System.Windows.Forms.BindingSource tb_AnggotaBindingSource;
        private System.Windows.Forms.BindingSource tb_ProdukBindingSource;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker Box_Tanggal2;
        private System.Windows.Forms.DateTimePicker Box_Tanggal1;
        internal System.Windows.Forms.TextBox textBox7;
        private Db_KasirKSDataSetTableAdapters.Tb_AnggotaTableAdapter tb_AnggotaTableAdapter;
        private Db_KasirKSDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private Db_KasirKSDataSetTableAdapters.Tb_DetailPenjualanTableAdapter tb_DetailPenjualanTableAdapter;
        private Db_KasirKSDataSetTableAdapters.Tb_PenjualanTableAdapter tb_PenjualanTableAdapter;
        private Db_KasirKSDataSetTableAdapters.Tb_ProdukTableAdapter tb_ProdukTableAdapter;
        private System.Windows.Forms.Button btnUp;
        private System.Windows.Forms.Button btnRefreshKotakTeks;
        private System.Windows.Forms.Button btnRefreshAnggota;
        private System.Windows.Forms.Button btnRefreshTanggal;
        internal System.Windows.Forms.Label labelNotif;
        private Guna.UI2.WinForms.Guna2CheckBox checkBoxTanggal;
    }
}
