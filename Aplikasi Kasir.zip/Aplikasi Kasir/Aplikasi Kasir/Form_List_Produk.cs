﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aplikasi_Kasir
{
    public partial class Form_List_Produk : Form
    {
        private readonly UcKasir KasirUc;
        private List<Db_KasirKSDataSet.Tb_ProdukRow> DataProduk;
        public Form_List_Produk(UcKasir kasirUc)
        {
            InitializeComponent();
            KasirUc = kasirUc;
        }
        // ===============================
        // 🔹 FORM LOAD
        // ===============================
        private void Form_List_Produk_Load(object sender, EventArgs e)
        {
            LoadDatabase();
            SetupComboBox();
            TampilkanData(DataProduk);

        }
        // ===============================
        // 🔹 LOAD DATABASE
        // ===============================
        private void LoadDatabase()
        {
            tb_ProdukTableAdapter.Fill(db_KasirKSDataSet.Tb_Produk);
            DataProduk = tb_ProdukTableAdapter.GetData().ToList();
        }

        // ===============================
        // 🔹 SETUP COMBOBOX
        // ===============================
        private void SetupComboBox()
        {
            comboBox1.Items.Clear();
            comboBox2.Items.Clear();

            comboBox1.Items.AddRange(new object[]
            {
                "ID Produk",
                "Kode Produk",
                "Nama Produk",
                "Harga",
                "Kuantitas",
                "Stok",
                "Keterangan"
            });

            comboBox2.Items.AddRange(new object[]
            {
                "Ascending",
                "Descending"
            });

            comboBox1.SelectedIndex = 0;
            comboBox2.SelectedIndex = 0;
        }

        // ===============================
        // 🔹 TAMPILKAN DATA
        // ===============================
        private void TampilkanData(List<Db_KasirKSDataSet.Tb_ProdukRow> data)
        {
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = data;
        }

        // ===============================
        // 🔹 SORTING
        // ===============================
        private void LakukanSortingProduk()
        {
            if (comboBox1.SelectedItem == null || comboBox2.SelectedItem == null)
                return;

            string kolom = comboBox1.SelectedItem.ToString();
            bool desc = comboBox2.SelectedItem.ToString() == "Descending";

            var sumber = dataGridView1.DataSource as List<Db_KasirKSDataSet.Tb_ProdukRow>;
            if (sumber == null) return;

            IEnumerable<Db_KasirKSDataSet.Tb_ProdukRow> query = sumber;

            switch (kolom)
            {
                case "ID Produk":
                    query = desc ? query.OrderByDescending(x => x.ID_Produk) : query.OrderBy(x => x.ID_Produk);
                    break;
                case "Kode Produk":
                    query = desc ? query.OrderByDescending(x => x.Kode_Produk) : query.OrderBy(x => x.Kode_Produk);
                    break;
                case "Nama Produk":
                    query = desc ? query.OrderByDescending(x => x.Nama_Produk) : query.OrderBy(x => x.Nama_Produk);
                    break;
                case "Harga":
                    query = desc ? query.OrderByDescending(x => x.Harga) : query.OrderBy(x => x.Harga);
                    break;
                case "Kuantitas":
                    query = desc ? query.OrderByDescending(x => x.Kuantitas) : query.OrderBy(x => x.Kuantitas);
                    break;
                case "Stok":
                    query = desc ? query.OrderByDescending(x => x.Stok) : query.OrderBy(x => x.Stok);
                    break;
                case "Keterangan":
                    query = desc ? query.OrderByDescending(x => x.Keterangan) : query.OrderBy(x => x.Keterangan);
                    break;
            }

            TampilkanData(query.ToList());
        }

        // ===============================
        // 🔹 FILTER
        // ===============================
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string filter = textBox1.Text.Trim();
            string kolom = comboBox1.SelectedItem?.ToString();

            if (string.IsNullOrEmpty(filter))
            {
                TampilkanData(DataProduk);
                LakukanSortingProduk();
                return;
            }

            IEnumerable<Db_KasirKSDataSet.Tb_ProdukRow> query = DataProduk;

            switch (kolom)
            {
                case "ID Produk":
                    query = query.Where(x => x.ID_Produk.ToString().Contains(filter));
                    break;
                case "Kode Produk":
                    query = query.Where(x => x.Kode_Produk.Contains(filter));
                    break;
                case "Nama Produk":
                    query = query.Where(x => x.Nama_Produk.Contains(filter));
                    break;
                case "Harga":
                    query = query.Where(x => x.Harga.ToString().Contains(filter));
                    break;
                case "Kuantitas":
                    query = query.Where(x => x.Kuantitas.Contains(filter));
                    break;
                case "Stok":
                    query = query.Where(x => x.Stok.ToString().Contains(filter));
                    break;
                case "Keterangan":
                    query = query.Where(x => x.Keterangan.Contains(filter));
                    break;
            }

            TampilkanData(query.ToList());
            LakukanSortingProduk();
        }
        // ===============================
        // 🔹 PILIH PRODUK (DOUBLE CLICK)
        // ===============================
        private void dataGridView1_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.Rows.Count > 0)
            {
                KasirUc.Box_IdProduk.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                KasirUc.Box_KodeProduk.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                KasirUc.Box_NamaProduk.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                KasirUc.Box_HargaProduk.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
                KasirUc.Box_Kuantitas.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
                KasirUc.Box_StokProduk.Text = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
                this.Close();
            }
        }
        // ===============================
        // 🔹 EVENT
        // ===============================
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            LakukanSortingProduk();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            LakukanSortingProduk();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
        }
    }
}
