﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aplikasi_Kasir
{
    public partial class UcAnggota : UserControl
    {
        public event EventHandler RefreshRequested;
        // =========================
        // LOAD & INIT
        // =========================
        private void UcAnggota_Load(object sender, EventArgs e)
        {
            tb_AnggotaTableAdapter.Fill(db_KasirKSDataSet.Tb_Anggota);
        }
        public UcAnggota()
        {
            InitializeComponent();

            InisialisasiComboBox();
            LoadDataAnggota();
            TampilkanTotalAnggota();
        }
        private void InisialisasiComboBox()
        {
            comboBox1.Items.AddRange(new object[]
            {
                "ID Anggota",
                "NIK",
                "No Anggota",
                "Nama Anggota",
                "Alamat",
                "No Telepon",
                "Keterangan",
                "No Rekening"
            });

            comboBox1.SelectedIndex = 0;

            comboBox2.Items.AddRange(new object[]
            {
                "Ascending",
                "Descending"
            });

            comboBox2.SelectedIndex = 0;
        }
        // =========================
        // LOAD & REFRESH DATA
        // =========================
        private void LoadDataAnggota()
        {
            dataGridView1.DataSource = tb_AnggotaTableAdapter.GetData().ToList();
        }

        private void TampilkanTotalAnggota()
        {
            int total = dataGridView1.Rows
                .Cast<DataGridViewRow>()
                .Count(r => !r.IsNewRow);

            labelTotalAnggota.Text = "Anggota:" + Environment.NewLine + total;
        }

        private void ClearTextBoxes()
        {
            Box_IdAnggota.Clear();
            Box_NikAnggota.Clear();
            Box_NoAnggota.Clear();
            Box_NamaAnggota.Clear();
            Box_Alamat.Clear();
            Box_NoTelepon.Clear();
            Box_Keterangan.Clear();
            Box_NoRekening.Clear();
        }

        // =========================
        // SORTING
        // =========================
        private void LakukanSortingAnggota()
        {
            if (comboBox1.SelectedItem == null || comboBox2.SelectedItem == null)
                return;

            var data = dataGridView1.DataSource as List<Db_KasirKSDataSet.Tb_AnggotaRow>;
            if (data == null || data.Count == 0)
                return;

            bool ascending = comboBox2.SelectedItem.ToString() == "Ascending";

            switch (comboBox1.SelectedItem.ToString())
            {
                case "ID Anggota":
                    data = ascending ? data.OrderBy(x => x.ID_Anggota).ToList()
                                     : data.OrderByDescending(x => x.ID_Anggota).ToList();
                    break;

                case "NIK":
                    data = ascending ? data.OrderBy(x => x.NIK).ToList()
                                     : data.OrderByDescending(x => x.NIK).ToList();
                    break;

                case "No Anggota":
                    data = ascending ? data.OrderBy(x => x.No_Anggota).ToList()
                                     : data.OrderByDescending(x => x.No_Anggota).ToList();
                    break;

                case "Nama Anggota":
                    data = ascending ? data.OrderBy(x => x.Nama_Anggota).ToList()
                                     : data.OrderByDescending(x => x.Nama_Anggota).ToList();
                    break;

                case "Alamat":
                    data = ascending ? data.OrderBy(x => x.Alamat).ToList()
                                     : data.OrderByDescending(x => x.Alamat).ToList();
                    break;

                case "No Telepon":
                    data = ascending ? data.OrderBy(x => x.No_Telepon).ToList()
                                     : data.OrderByDescending(x => x.No_Telepon).ToList();
                    break;

                case "Keterangan":
                    data = ascending ? data.OrderBy(x => x.Keterangan).ToList()
                                     : data.OrderByDescending(x => x.Keterangan).ToList();
                    break;

                case "No Rekening":
                    data = ascending ? data.OrderBy(x => x.No_Rekening).ToList()
                                     : data.OrderByDescending(x => x.No_Rekening).ToList();
                    break;
            }

            dataGridView1.DataSource = data;
        }
        // =========================
        // CRUD
        // =========================
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                tb_AnggotaTableAdapter.TambahAnggota(
                    Convert.ToInt64(Box_IdAnggota.Text),
                    Convert.ToInt64(Box_NikAnggota.Text),
                    Box_NoAnggota.Text,
                    Box_NamaAnggota.Text,
                    Box_Alamat.Text,
                    Box_NoTelepon.Text,
                    Box_Keterangan.Text,
                    Box_NoRekening.Text
                );

                LoadDataAnggota();
                TampilkanTotalAnggota();

                MessageBox.Show("Data anggota berhasil ditambahkan!", "Sukses",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
                return;

            if (MessageBox.Show("Hapus data anggota ini?", "Konfirmasi",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            try
            {
                int id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
                tb_AnggotaTableAdapter.HapusAnggota(id);

                LoadDataAnggota();
                TampilkanTotalAnggota();
                ClearTextBoxes();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Box_IdAnggota.Text))
                return;

            try
            {
                tb_AnggotaTableAdapter.UpdateAnggota(
                    Convert.ToInt64(Box_IdAnggota.Text),
                    Convert.ToInt64(Box_NikAnggota.Text),
                    Box_NoAnggota.Text,
                    Box_NamaAnggota.Text,
                    Box_Alamat.Text,
                    Box_NoTelepon.Text,
                    Box_Keterangan.Text,
                    Box_NoRekening.Text
                );

                LoadDataAnggota();
                TampilkanTotalAnggota();
                ClearTextBoxes();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        // =========================
        // FILTER
        // =========================
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string filter = textBox1.Text.Trim();
            var data = tb_AnggotaTableAdapter.GetData();

            if (string.IsNullOrEmpty(filter))
            {
                dataGridView1.DataSource = data.ToList();
                LakukanSortingAnggota();
                return;
            }

            List<Db_KasirKSDataSet.Tb_AnggotaRow> hasil = null;

            switch (comboBox1.SelectedItem.ToString())
            {
                case "ID Anggota":
                    hasil = data.Where(x => x.ID_Anggota.ToString().Contains(filter)).ToList();
                    break;
                case "NIK":
                    hasil = data.Where(x => x.NIK.ToString().Contains(filter)).ToList();
                    break;
                case "No Anggota":
                    hasil = data.Where(x => x.No_Anggota.Contains(filter)).ToList();
                    break;
                case "Nama Anggota":
                    hasil = data.Where(x => x.Nama_Anggota.Contains(filter)).ToList();
                    break;
                case "Alamat":
                    hasil = data.Where(x => x.Alamat.Contains(filter)).ToList();
                    break;
                case "No Telepon":
                    hasil = data.Where(x => x.No_Telepon.Contains(filter)).ToList();
                    break;
                case "Keterangan":
                    hasil = data.Where(x => x.Keterangan.Contains(filter)).ToList();
                    break;
                case "No Rekening":
                    hasil = data.Where(x => x.No_Rekening.Contains(filter)).ToList();
                    break;
            }

            dataGridView1.DataSource = hasil;
            LakukanSortingAnggota();
        }
        // =========================
        // UI EVENT
        // =========================
        private void dataGridView1_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            var row = dataGridView1.Rows[e.RowIndex];

            Box_IdAnggota.Text = row.Cells[0].Value.ToString();
            Box_NikAnggota.Text = row.Cells[1].Value.ToString();
            Box_NoAnggota.Text = row.Cells[2].Value.ToString();
            Box_NamaAnggota.Text = row.Cells[3].Value.ToString();
            Box_Alamat.Text = row.Cells[4].Value.ToString();
            Box_NoTelepon.Text = row.Cells[5].Value.ToString();
            Box_Keterangan.Text = row.Cells[6].Value.ToString();
            Box_NoRekening.Text = row.Cells[7].Value.ToString();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            ClearTextBoxes();
            RefreshRequested?.Invoke(this, EventArgs.Empty);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            LakukanSortingAnggota();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            LakukanSortingAnggota();
        }
    }
}
