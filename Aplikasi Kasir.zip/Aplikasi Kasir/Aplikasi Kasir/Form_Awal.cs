﻿using Guna.UI2.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Text.RegularExpressions;

namespace Aplikasi_Kasir
{
    public partial class Form_Awal : Form
    {
        private string currentUC = string.Empty;
        private string userRole = string.Empty;

        // Simpan instance UserControl
        private UcKasir ucKasir;
        private UcDashboard ucDashboard;

        int sidebarExpandWidth = 265;
        int sidebarCollapseWidth = 52;
        int sidebarSpeed = 15;   // kecepatan animasi
        bool isSidebarExpanded = false;

        public Form_Awal(string role)
        {
            InitializeComponent();
            userRole = role;
        }

        private void Form_Awal_Load(object sender, EventArgs e)
        {
            // LABEL ROLE
            labelRole.Text = $"Anda Login Sebagai : {userRole}";

            ShowAccessMessage();
            LoadDefaultUserControlByRole();

            PanelSidebar.MouseEnter += panelSidebar_MouseEnter;
            PanelSidebar.MouseLeave += panelSidebar_MouseLeave;
            RegisterSidebarHover(PanelSidebar);

            PanelSidebar.Width = sidebarCollapseWidth;

            // PanelUtama DIAM
            PanelUtama.Location = new Point(52, 35);

        }
        private void RegisterSidebarHover(Control parent)
        {
            foreach (Control ctrl in parent.Controls)
            {
                ctrl.MouseEnter += panelSidebar_MouseEnter;
                ctrl.MouseLeave += panelSidebar_MouseLeave;

                // Kalau ada control bersarang (misal panel dalam panel)
                if (ctrl.HasChildren)
                    RegisterSidebarHover(ctrl);
            }
        }
        private void Form_Awal_FormClosing(object sender, FormClosingEventArgs e)
        {
            // minta izin dari UcKasir dulu
            if (!BatalkanTransaksiJikaAda())
            {
                e.Cancel = true;
                return;
            }

            DialogResult result = MessageBox.Show(
                "Apakah Anda yakin ingin keluar dari aplikasi?",
                "Konfirmasi Keluar",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.No)
                e.Cancel = true;
        }

        private void Form_Awal_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void LoadUserControl(UserControl uc, string ucName)
        {
            PanelUtama.Controls.Clear();
            uc.Dock = DockStyle.Fill;
            PanelUtama.Controls.Add(uc);
            currentUC = ucName;

            // 🔹 UPDATE LABEL MENU
            string menuName = ucName.Replace("Uc", "");
            labelMenu.Text = Regex.Replace(menuName, "(?<!^)([A-Z])", " $1");
        }

        private void LoadDefaultUserControlByRole()
        {
            if (userRole == "Owner" || userRole == "Manager")
            {
                if (ucDashboard == null)
                    ucDashboard = new UcDashboard();

                LoadUserControl(ucDashboard, "UcDashboard");
            }
            else if (userRole == "Kasir")
            {
                if (ucKasir == null)
                    ucKasir = new UcKasir();

                LoadUserControl(ucKasir, "UcKasir");
            }
            else if (userRole == "Gudang")
            {
                LoadUserControl(new UcProduk(), "UcProduk");
            }
            else if (userRole == "Akuntan")
            {
                LoadUserControl(new UcPenjualan(), "UcPenjualan");
            }
            else
            {
                if (ucDashboard == null)
                    ucDashboard = new UcDashboard();

                LoadUserControl(ucDashboard, "UcDashboard");
            }
        }
        private bool HasAccess(string buttonName)
        {
            if (userRole == "Owner")
                return true;

            if (userRole == "Manager")
                return buttonName != "btnKasir";

            if (userRole == "Kasir")
                return buttonName == "btnKasir"
                    || buttonName == "btnPenjualan"
                    || buttonName == "btnDetailPenjualan"
                    || buttonName == "btnFaktur";

            if (userRole == "Gudang")
                return buttonName == "btnProduk";

            if (userRole == "Akuntan")
                return buttonName == "btnPenjualan"
                    || buttonName == "btnDetailPenjualan"
                    || buttonName == "btnFaktur";

            return false;
        }

        private void ShowAccessMessage()
        {
            string akses = "-";

            if (userRole == "Owner")
                akses = "Semua fitur dapat diakses.";
            else if (userRole == "Manager")
                akses = "Dashboard, Penjualan, Detail Penjualan, Anggota, Produk.";
            else if (userRole == "Kasir")
                akses = "Kasir, Penjualan, Detail Penjualan.";
            else if (userRole == "Gudang")
                akses = "Produk.";
            else if (userRole == "Akuntan")
                akses = "Penjualan, Detail Penjualan.";

            MessageBox.Show(
                "Login sebagai " + userRole + "\nAkses: " + akses,
                "Informasi Akses",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        private void AksesDibatasi()
        {
            MessageBox.Show(
                "Anda tidak memiliki akses ke menu ini!",
                "Akses Ditolak",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
        }
        private bool BatalkanTransaksiJikaAda()
        {
            if (ucKasir == null)
                return true;

            if (!ucKasir.AdaTransaksiBerjalan())
                return true;

            DialogResult result = MessageBox.Show(
                "Masih ada transaksi yang belum disimpan.\n" +
                "Jika Anda melanjutkan, transaksi akan dibatalkan.\n\n" +
                "Lanjutkan?",
                "Konfirmasi Transaksi",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);

            if (result == DialogResult.Yes)
            {
                ucKasir.BatalkanTransaksi();
                return true;
            }

            return false;
        }
        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (!BatalkanTransaksiJikaAda()) return;

            new Form_Login().Show();
            this.Hide();
        }
        private void btnDashboard_Click(object sender, EventArgs e)
        {
            LoadMenu("btnDashboard", "UcDashboard", delegate
            {
                if (ucDashboard == null)
                    ucDashboard = new UcDashboard();
                return ucDashboard;
            });
        }
        private void btnKasir_Click(object sender, EventArgs e)
        {
            LoadMenu("btnKasir", "UcKasir", () =>
            {
                ucKasir = new UcKasir();
                return ucKasir;
            });
        }
        private void btnPenjualan_Click(object sender, EventArgs e)
        {
            LoadMenu("btnPenjualan", "UcPenjualan", () => new UcPenjualan());
        }
        private void btnDetailPenjualan_Click(object sender, EventArgs e)
        {
            LoadMenu("btnDetailPenjualan", "UcDetailPenjualan", () => new UcDetailPenjualan());
        }
        private void btnAnggota_Click(object sender, EventArgs e)
        {
            LoadMenu("btnAnggota", "UcAnggota", () => new UcAnggota());
        }
        private void btnProduk_Click(object sender, EventArgs e)
        {
            LoadMenu("btnProduk", "UcProduk", () => new UcProduk());
        }
        private void btnRefresh_Click_1(object sender, EventArgs e)
        {
            if (!BatalkanTransaksiJikaAda()) return; // 🧩 Tambahkan ini

            if (PanelUtama.Controls.Count > 0)
            {
                var currentUCControl = PanelUtama.Controls[0];
                var type = currentUCControl.GetType();

                // Buat ulang UserControl yang sama untuk menyegarkan tampilan dan data
                UserControl newUC = (UserControl)Activator.CreateInstance(type);

                PanelUtama.Controls.Clear();
                newUC.Dock = DockStyle.Fill;
                PanelUtama.Controls.Add(newUC);

                MessageBox.Show("Tampilan berhasil diperbarui!",
                    "Refresh Berhasil",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
        }
        private void btnFaktur_Click(object sender, EventArgs e)
        {
            LoadMenu("btnFaktur", "UcFaktur", () => new UcFaktur());
        }
        private void LoadMenu(string buttonName, string ucName, Func<UserControl> ucFactory)
        {
            if (!BatalkanTransaksiJikaAda()) return;

            if (!HasAccess(buttonName))
            {
                AksesDibatasi();
                return;
            }

            if (currentUC == ucName)
            {
                MessageBox.Show(
                    $"Anda sudah berada di menu {ucName.Replace("Uc", "")}.",
                    "Informasi",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                return;
            }

            LoadUserControl(ucFactory(), ucName);
        }

        private void panelSidebar_MouseEnter(object sender, EventArgs e)
        {
            isSidebarExpanded = true;
            timerSidebar.Start();
        }

        private void panelSidebar_MouseLeave(object sender, EventArgs e)
        {
            isSidebarExpanded = false;
            timerSidebar.Start();
        }

        private void timerSidebar_Tick(object sender, EventArgs e)
        {
            if (isSidebarExpanded)
            {
                if (PanelSidebar.Width < sidebarExpandWidth)
                {
                    PanelSidebar.Width += sidebarSpeed;
                }
                else
                {
                    PanelSidebar.Width = sidebarExpandWidth;
                    timerSidebar.Stop();
                }
            }
            else
            {
                if (PanelSidebar.Width > sidebarCollapseWidth)
                {
                    PanelSidebar.Width -= sidebarSpeed;
                }
                else
                {
                    PanelSidebar.Width = sidebarCollapseWidth;
                    timerSidebar.Stop();
                }
            }
        }
        
        private void PanelTopbar_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            
        }
        private void PanelTopbar_MouseDown(object sender, MouseEventArgs e)
        {

        }

        private void PanelTopbar_MouseMove(object sender, MouseEventArgs e)
        {

        }
    }
}
