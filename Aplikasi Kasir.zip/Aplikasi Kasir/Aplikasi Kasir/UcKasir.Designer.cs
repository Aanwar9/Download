﻿namespace Aplikasi_Kasir
{
    partial class UcKasir
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.db_KasirKSDataSet = new Aplikasi_Kasir.Db_KasirKSDataSet();
            this.joinTabelKasirBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.joinTabelKasirTableAdapter = new Aplikasi_Kasir.Db_KasirKSDataSetTableAdapters.JoinTabelKasirTableAdapter();
            this.tableAdapterManager = new Aplikasi_Kasir.Db_KasirKSDataSetTableAdapters.TableAdapterManager();
            this.tb_DetailPenjualanTableAdapter = new Aplikasi_Kasir.Db_KasirKSDataSetTableAdapters.Tb_DetailPenjualanTableAdapter();
            this.tb_PenjualanTableAdapter = new Aplikasi_Kasir.Db_KasirKSDataSetTableAdapters.Tb_PenjualanTableAdapter();
            this.tb_ProdukTableAdapter = new Aplikasi_Kasir.Db_KasirKSDataSetTableAdapters.Tb_ProdukTableAdapter();
            this.tb_DetailPenjualanBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tb_PenjualanBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tb_ProdukBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.panel2 = new System.Windows.Forms.Panel();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iDDetailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.namaAnggotaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kodeProdukDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.namaProdukDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kuantitasDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hargaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.jumlahBeliDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.diskonDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subTotalDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label18 = new System.Windows.Forms.Label();
            this.GrandTotal = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.GrandBanyak = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnBayarLangsung = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.btnBayar = new System.Windows.Forms.Button();
            this.Box_Bayar = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.Box_Kembalian = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.Box_Tanggal = new System.Windows.Forms.DateTimePicker();
            this.btnTambahkan = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.btnPelangganUmum = new System.Windows.Forms.Button();
            this.btnListAnggota = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.Box_NamaAnggota = new System.Windows.Forms.TextBox();
            this.Box_IdAnggota = new System.Windows.Forms.TextBox();
            this.Box_Kuantitas = new System.Windows.Forms.TextBox();
            this.Box_StokProduk = new System.Windows.Forms.TextBox();
            this.btnListProduk = new System.Windows.Forms.Button();
            this.Box_HargaProduk = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Box_IdProduk = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Box_NamaProduk = new System.Windows.Forms.TextBox();
            this.Box_KodeProduk = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.Box_Diskon = new System.Windows.Forms.TextBox();
            this.Box_JumlahBeli = new System.Windows.Forms.TextBox();
            this.Box_SubTotal = new System.Windows.Forms.TextBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.hapusItemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.db_KasirKSDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.joinTabelKasirBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tb_DetailPenjualanBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tb_PenjualanBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tb_ProdukBindingSource)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel3.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // db_KasirKSDataSet
            // 
            this.db_KasirKSDataSet.DataSetName = "Db_KasirKSDataSet";
            this.db_KasirKSDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // joinTabelKasirBindingSource
            // 
            this.joinTabelKasirBindingSource.DataMember = "JoinTabelKasir";
            this.joinTabelKasirBindingSource.DataSource = this.db_KasirKSDataSet;
            // 
            // joinTabelKasirTableAdapter
            // 
            this.joinTabelKasirTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Tb_AnggotaTableAdapter = null;
            this.tableAdapterManager.Tb_DetailPenjualanTableAdapter = this.tb_DetailPenjualanTableAdapter;
            this.tableAdapterManager.Tb_PenjualanTableAdapter = this.tb_PenjualanTableAdapter;
            this.tableAdapterManager.Tb_ProdukTableAdapter = this.tb_ProdukTableAdapter;
            this.tableAdapterManager.UpdateOrder = Aplikasi_Kasir.Db_KasirKSDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // tb_DetailPenjualanTableAdapter
            // 
            this.tb_DetailPenjualanTableAdapter.ClearBeforeFill = true;
            // 
            // tb_PenjualanTableAdapter
            // 
            this.tb_PenjualanTableAdapter.ClearBeforeFill = true;
            // 
            // tb_ProdukTableAdapter
            // 
            this.tb_ProdukTableAdapter.ClearBeforeFill = true;
            // 
            // tb_DetailPenjualanBindingSource
            // 
            this.tb_DetailPenjualanBindingSource.DataMember = "Tb_DetailPenjualan";
            this.tb_DetailPenjualanBindingSource.DataSource = this.db_KasirKSDataSet;
            // 
            // tb_PenjualanBindingSource
            // 
            this.tb_PenjualanBindingSource.DataMember = "Tb_Penjualan";
            this.tb_PenjualanBindingSource.DataSource = this.db_KasirKSDataSet;
            // 
            // tb_ProdukBindingSource
            // 
            this.tb_ProdukBindingSource.DataMember = "Tb_Produk";
            this.tb_ProdukBindingSource.DataSource = this.db_KasirKSDataSet;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.SteelBlue;
            this.panel2.Controls.Add(this.comboBox2);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.btnRefresh);
            this.panel2.Controls.Add(this.comboBox1);
            this.panel2.Controls.Add(this.textBox9);
            this.panel2.Location = new System.Drawing.Point(3, 14);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1444, 50);
            this.panel2.TabIndex = 69;
            // 
            // comboBox2
            // 
            this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(1037, 7);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(137, 24);
            this.comboBox2.TabIndex = 69;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.Highlight;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Segoe UI Emoji", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(828, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(55, 38);
            this.button1.TabIndex = 69;
            this.button1.Text = "❌";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRefresh.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefresh.ForeColor = System.Drawing.Color.White;
            this.btnRefresh.Location = new System.Drawing.Point(1180, 5);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(261, 38);
            this.btnRefresh.TabIndex = 19;
            this.btnRefresh.Text = "🔄   Refresh Kotak Teks";
            this.btnRefresh.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRefresh.UseVisualStyleBackColor = false;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(890, 7);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(137, 24);
            this.comboBox1.TabIndex = 26;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // textBox9
            // 
            this.textBox9.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox9.Location = new System.Drawing.Point(12, 7);
            this.textBox9.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(809, 34);
            this.textBox9.TabIndex = 25;
            this.textBox9.TextChanged += new System.EventHandler(this.textBox9_TextChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDetailDataGridViewTextBoxColumn,
            this.namaAnggotaDataGridViewTextBoxColumn,
            this.kodeProdukDataGridViewTextBoxColumn,
            this.namaProdukDataGridViewTextBoxColumn,
            this.kuantitasDataGridViewTextBoxColumn,
            this.hargaDataGridViewTextBoxColumn,
            this.jumlahBeliDataGridViewTextBoxColumn,
            this.diskonDataGridViewTextBoxColumn,
            this.subTotalDataGridViewTextBoxColumn});
            this.dataGridView1.ContextMenuStrip = this.contextMenuStrip1;
            this.dataGridView1.DataSource = this.joinTabelKasirBindingSource;
            this.dataGridView1.EnableHeadersVisualStyles = false;
            this.dataGridView1.GridColor = System.Drawing.Color.White;
            this.dataGridView1.Location = new System.Drawing.Point(4, 72);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 51;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.SteelBlue;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(1415, 835);
            this.dataGridView1.TabIndex = 70;
            // 
            // iDDetailDataGridViewTextBoxColumn
            // 
            this.iDDetailDataGridViewTextBoxColumn.DataPropertyName = "ID_Detail";
            this.iDDetailDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDetailDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.iDDetailDataGridViewTextBoxColumn.Name = "iDDetailDataGridViewTextBoxColumn";
            this.iDDetailDataGridViewTextBoxColumn.ReadOnly = true;
            this.iDDetailDataGridViewTextBoxColumn.Width = 40;
            // 
            // namaAnggotaDataGridViewTextBoxColumn
            // 
            this.namaAnggotaDataGridViewTextBoxColumn.DataPropertyName = "Nama_Anggota";
            this.namaAnggotaDataGridViewTextBoxColumn.HeaderText = "Anggota";
            this.namaAnggotaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.namaAnggotaDataGridViewTextBoxColumn.Name = "namaAnggotaDataGridViewTextBoxColumn";
            this.namaAnggotaDataGridViewTextBoxColumn.ReadOnly = true;
            this.namaAnggotaDataGridViewTextBoxColumn.Width = 135;
            // 
            // kodeProdukDataGridViewTextBoxColumn
            // 
            this.kodeProdukDataGridViewTextBoxColumn.DataPropertyName = "Kode_Produk";
            this.kodeProdukDataGridViewTextBoxColumn.HeaderText = "Kode";
            this.kodeProdukDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.kodeProdukDataGridViewTextBoxColumn.Name = "kodeProdukDataGridViewTextBoxColumn";
            this.kodeProdukDataGridViewTextBoxColumn.ReadOnly = true;
            this.kodeProdukDataGridViewTextBoxColumn.Width = 130;
            // 
            // namaProdukDataGridViewTextBoxColumn
            // 
            this.namaProdukDataGridViewTextBoxColumn.DataPropertyName = "Nama_Produk";
            this.namaProdukDataGridViewTextBoxColumn.HeaderText = "Produk";
            this.namaProdukDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.namaProdukDataGridViewTextBoxColumn.Name = "namaProdukDataGridViewTextBoxColumn";
            this.namaProdukDataGridViewTextBoxColumn.ReadOnly = true;
            this.namaProdukDataGridViewTextBoxColumn.Width = 150;
            // 
            // kuantitasDataGridViewTextBoxColumn
            // 
            this.kuantitasDataGridViewTextBoxColumn.DataPropertyName = "Kuantitas";
            this.kuantitasDataGridViewTextBoxColumn.HeaderText = "QTY";
            this.kuantitasDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.kuantitasDataGridViewTextBoxColumn.Name = "kuantitasDataGridViewTextBoxColumn";
            this.kuantitasDataGridViewTextBoxColumn.ReadOnly = true;
            this.kuantitasDataGridViewTextBoxColumn.Width = 60;
            // 
            // hargaDataGridViewTextBoxColumn
            // 
            this.hargaDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.hargaDataGridViewTextBoxColumn.DataPropertyName = "Harga";
            this.hargaDataGridViewTextBoxColumn.HeaderText = "Harga";
            this.hargaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.hargaDataGridViewTextBoxColumn.Name = "hargaDataGridViewTextBoxColumn";
            this.hargaDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // jumlahBeliDataGridViewTextBoxColumn
            // 
            this.jumlahBeliDataGridViewTextBoxColumn.DataPropertyName = "Jumlah_Beli";
            this.jumlahBeliDataGridViewTextBoxColumn.HeaderText = "Jumlah";
            this.jumlahBeliDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.jumlahBeliDataGridViewTextBoxColumn.Name = "jumlahBeliDataGridViewTextBoxColumn";
            this.jumlahBeliDataGridViewTextBoxColumn.ReadOnly = true;
            this.jumlahBeliDataGridViewTextBoxColumn.Width = 65;
            // 
            // diskonDataGridViewTextBoxColumn
            // 
            this.diskonDataGridViewTextBoxColumn.DataPropertyName = "Diskon";
            this.diskonDataGridViewTextBoxColumn.HeaderText = "Diskon";
            this.diskonDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.diskonDataGridViewTextBoxColumn.Name = "diskonDataGridViewTextBoxColumn";
            this.diskonDataGridViewTextBoxColumn.ReadOnly = true;
            this.diskonDataGridViewTextBoxColumn.Width = 65;
            // 
            // subTotalDataGridViewTextBoxColumn
            // 
            this.subTotalDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.subTotalDataGridViewTextBoxColumn.DataPropertyName = "Sub_Total";
            this.subTotalDataGridViewTextBoxColumn.HeaderText = "Total";
            this.subTotalDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.subTotalDataGridViewTextBoxColumn.Name = "subTotalDataGridViewTextBoxColumn";
            this.subTotalDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SteelBlue;
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.GrandTotal);
            this.panel1.Controls.Add(this.label19);
            this.panel1.Controls.Add(this.GrandBanyak);
            this.panel1.Location = new System.Drawing.Point(1426, 72);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(407, 187);
            this.panel1.TabIndex = 71;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(14, 14);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(172, 28);
            this.label18.TabIndex = 45;
            this.label18.Text = "Total Pembayaran";
            // 
            // GrandTotal
            // 
            this.GrandTotal.AutoSize = true;
            this.GrandTotal.BackColor = System.Drawing.Color.Transparent;
            this.GrandTotal.Font = new System.Drawing.Font("Segoe UI", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GrandTotal.ForeColor = System.Drawing.Color.Red;
            this.GrandTotal.Location = new System.Drawing.Point(10, 35);
            this.GrandTotal.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.GrandTotal.Name = "GrandTotal";
            this.GrandTotal.Size = new System.Drawing.Size(235, 62);
            this.GrandTotal.TabIndex = 17;
            this.GrandTotal.Text = "Rp000,00";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(16, 95);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(124, 28);
            this.label19.TabIndex = 46;
            this.label19.Text = "Total Barang";
            // 
            // GrandBanyak
            // 
            this.GrandBanyak.AutoSize = true;
            this.GrandBanyak.BackColor = System.Drawing.Color.Transparent;
            this.GrandBanyak.Font = new System.Drawing.Font("Segoe UI", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GrandBanyak.ForeColor = System.Drawing.Color.Red;
            this.GrandBanyak.Location = new System.Drawing.Point(12, 116);
            this.GrandBanyak.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.GrandBanyak.Name = "GrandBanyak";
            this.GrandBanyak.Size = new System.Drawing.Size(108, 62);
            this.GrandBanyak.TabIndex = 17;
            this.GrandBanyak.Text = "000";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.SteelBlue;
            this.panel5.Controls.Add(this.btnBayarLangsung);
            this.panel5.Controls.Add(this.label20);
            this.panel5.Controls.Add(this.btnBayar);
            this.panel5.Controls.Add(this.Box_Bayar);
            this.panel5.Controls.Add(this.label14);
            this.panel5.Controls.Add(this.Box_Kembalian);
            this.panel5.Location = new System.Drawing.Point(1425, 265);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(408, 169);
            this.panel5.TabIndex = 72;
            // 
            // btnBayarLangsung
            // 
            this.btnBayarLangsung.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnBayarLangsung.FlatAppearance.BorderColor = System.Drawing.Color.Lime;
            this.btnBayarLangsung.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBayarLangsung.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBayarLangsung.ForeColor = System.Drawing.Color.Lime;
            this.btnBayarLangsung.Location = new System.Drawing.Point(17, 99);
            this.btnBayarLangsung.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnBayarLangsung.Name = "btnBayarLangsung";
            this.btnBayarLangsung.Size = new System.Drawing.Size(129, 55);
            this.btnBayarLangsung.TabIndex = 37;
            this.btnBayarLangsung.Text = "🔁 💵";
            this.btnBayarLangsung.UseVisualStyleBackColor = false;
            this.btnBayarLangsung.Click += new System.EventHandler(this.btnBayarLangsung_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.Location = new System.Drawing.Point(12, 58);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(107, 28);
            this.label20.TabIndex = 71;
            this.label20.Text = "Kembalian";
            // 
            // btnBayar
            // 
            this.btnBayar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnBayar.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
            this.btnBayar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBayar.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBayar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnBayar.Location = new System.Drawing.Point(248, 99);
            this.btnBayar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnBayar.Name = "btnBayar";
            this.btnBayar.Size = new System.Drawing.Size(129, 55);
            this.btnBayar.TabIndex = 36;
            this.btnBayar.Text = "📝 💵";
            this.btnBayar.UseVisualStyleBackColor = false;
            this.btnBayar.Click += new System.EventHandler(this.btnBayar_Click);
            // 
            // Box_Bayar
            // 
            this.Box_Bayar.Location = new System.Drawing.Point(136, 11);
            this.Box_Bayar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Box_Bayar.Name = "Box_Bayar";
            this.Box_Bayar.Size = new System.Drawing.Size(241, 22);
            this.Box_Bayar.TabIndex = 24;
            this.Box_Bayar.TextChanged += new System.EventHandler(this.Box_Bayar_TextChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(14, 14);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(61, 28);
            this.label14.TabIndex = 70;
            this.label14.Text = "Bayar";
            // 
            // Box_Kembalian
            // 
            this.Box_Kembalian.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Box_Kembalian.Location = new System.Drawing.Point(136, 55);
            this.Box_Kembalian.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Box_Kembalian.Name = "Box_Kembalian";
            this.Box_Kembalian.ReadOnly = true;
            this.Box_Kembalian.Size = new System.Drawing.Size(241, 22);
            this.Box_Kembalian.TabIndex = 26;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.SteelBlue;
            this.panel4.Controls.Add(this.label4);
            this.panel4.Controls.Add(this.Box_Tanggal);
            this.panel4.Controls.Add(this.btnTambahkan);
            this.panel4.Location = new System.Drawing.Point(1425, 440);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(408, 149);
            this.panel4.TabIndex = 73;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(4, 9);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(82, 28);
            this.label4.TabIndex = 42;
            this.label4.Text = "Tanggal";
            // 
            // Box_Tanggal
            // 
            this.Box_Tanggal.Location = new System.Drawing.Point(9, 42);
            this.Box_Tanggal.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Box_Tanggal.Name = "Box_Tanggal";
            this.Box_Tanggal.Size = new System.Drawing.Size(392, 22);
            this.Box_Tanggal.TabIndex = 4;
            // 
            // btnTambahkan
            // 
            this.btnTambahkan.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnTambahkan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTambahkan.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTambahkan.ForeColor = System.Drawing.Color.White;
            this.btnTambahkan.Location = new System.Drawing.Point(9, 87);
            this.btnTambahkan.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnTambahkan.Name = "btnTambahkan";
            this.btnTambahkan.Size = new System.Drawing.Size(392, 50);
            this.btnTambahkan.TabIndex = 36;
            this.btnTambahkan.Text = "➕ Tambahkan Ke List Penjualan ➡️ 📋";
            this.btnTambahkan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTambahkan.UseVisualStyleBackColor = false;
            this.btnTambahkan.Click += new System.EventHandler(this.btnTambahkan_Click);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.SteelBlue;
            this.panel6.Controls.Add(this.button2);
            this.panel6.Controls.Add(this.label3);
            this.panel6.Controls.Add(this.btnPelangganUmum);
            this.panel6.Controls.Add(this.btnListAnggota);
            this.panel6.Controls.Add(this.label1);
            this.panel6.Controls.Add(this.label8);
            this.panel6.Controls.Add(this.Box_NamaAnggota);
            this.panel6.Controls.Add(this.Box_IdAnggota);
            this.panel6.Controls.Add(this.Box_Kuantitas);
            this.panel6.Controls.Add(this.Box_StokProduk);
            this.panel6.Controls.Add(this.btnListProduk);
            this.panel6.Controls.Add(this.Box_HargaProduk);
            this.panel6.Controls.Add(this.label16);
            this.panel6.Controls.Add(this.label9);
            this.panel6.Controls.Add(this.label5);
            this.panel6.Controls.Add(this.Box_IdProduk);
            this.panel6.Controls.Add(this.label2);
            this.panel6.Controls.Add(this.Box_NamaProduk);
            this.panel6.Controls.Add(this.Box_KodeProduk);
            this.panel6.Controls.Add(this.label7);
            this.panel6.Location = new System.Drawing.Point(4, 915);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(1027, 149);
            this.panel6.TabIndex = 74;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.Highlight;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Segoe UI Emoji", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(540, 14);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(55, 38);
            this.button2.TabIndex = 70;
            this.button2.Text = "❌";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(216, 14);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 28);
            this.label3.TabIndex = 5;
            this.label3.Text = "Nama";
            // 
            // btnPelangganUmum
            // 
            this.btnPelangganUmum.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnPelangganUmum.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPelangganUmum.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPelangganUmum.ForeColor = System.Drawing.Color.White;
            this.btnPelangganUmum.Location = new System.Drawing.Point(603, 11);
            this.btnPelangganUmum.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnPelangganUmum.Name = "btnPelangganUmum";
            this.btnPelangganUmum.Size = new System.Drawing.Size(241, 44);
            this.btnPelangganUmum.TabIndex = 9;
            this.btnPelangganUmum.Text = "🎲 👥";
            this.btnPelangganUmum.UseVisualStyleBackColor = false;
            this.btnPelangganUmum.Click += new System.EventHandler(this.btnPelangganUmum_Click);
            // 
            // btnListAnggota
            // 
            this.btnListAnggota.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnListAnggota.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnListAnggota.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnListAnggota.ForeColor = System.Drawing.Color.White;
            this.btnListAnggota.Location = new System.Drawing.Point(866, 11);
            this.btnListAnggota.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnListAnggota.Name = "btnListAnggota";
            this.btnListAnggota.Size = new System.Drawing.Size(129, 55);
            this.btnListAnggota.TabIndex = 8;
            this.btnListAnggota.Text = "📋 👤";
            this.btnListAnggota.UseVisualStyleBackColor = false;
            this.btnListAnggota.Click += new System.EventHandler(this.btnListAnggota_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(14, 14);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 28);
            this.label1.TabIndex = 0;
            this.label1.Text = "Anggota ID";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(216, 103);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(66, 28);
            this.label8.TabIndex = 15;
            this.label8.Text = "Harga";
            // 
            // Box_NamaAnggota
            // 
            this.Box_NamaAnggota.Location = new System.Drawing.Point(288, 14);
            this.Box_NamaAnggota.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Box_NamaAnggota.Name = "Box_NamaAnggota";
            this.Box_NamaAnggota.ReadOnly = true;
            this.Box_NamaAnggota.Size = new System.Drawing.Size(241, 22);
            this.Box_NamaAnggota.TabIndex = 7;
            // 
            // Box_IdAnggota
            // 
            this.Box_IdAnggota.Location = new System.Drawing.Point(135, 11);
            this.Box_IdAnggota.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Box_IdAnggota.Name = "Box_IdAnggota";
            this.Box_IdAnggota.Size = new System.Drawing.Size(70, 22);
            this.Box_IdAnggota.TabIndex = 1;
            // 
            // Box_Kuantitas
            // 
            this.Box_Kuantitas.Location = new System.Drawing.Point(603, 103);
            this.Box_Kuantitas.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Box_Kuantitas.Name = "Box_Kuantitas";
            this.Box_Kuantitas.ReadOnly = true;
            this.Box_Kuantitas.Size = new System.Drawing.Size(70, 22);
            this.Box_Kuantitas.TabIndex = 23;
            // 
            // Box_StokProduk
            // 
            this.Box_StokProduk.Location = new System.Drawing.Point(740, 100);
            this.Box_StokProduk.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Box_StokProduk.Name = "Box_StokProduk";
            this.Box_StokProduk.ReadOnly = true;
            this.Box_StokProduk.Size = new System.Drawing.Size(104, 22);
            this.Box_StokProduk.TabIndex = 18;
            // 
            // btnListProduk
            // 
            this.btnListProduk.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnListProduk.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnListProduk.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnListProduk.ForeColor = System.Drawing.Color.White;
            this.btnListProduk.Location = new System.Drawing.Point(866, 79);
            this.btnListProduk.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnListProduk.Name = "btnListProduk";
            this.btnListProduk.Size = new System.Drawing.Size(129, 55);
            this.btnListProduk.TabIndex = 19;
            this.btnListProduk.Text = "📋 📦";
            this.btnListProduk.UseVisualStyleBackColor = false;
            this.btnListProduk.Click += new System.EventHandler(this.btnListProduk_Click);
            // 
            // Box_HargaProduk
            // 
            this.Box_HargaProduk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Box_HargaProduk.Location = new System.Drawing.Point(288, 103);
            this.Box_HargaProduk.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Box_HargaProduk.Name = "Box_HargaProduk";
            this.Box_HargaProduk.ReadOnly = true;
            this.Box_HargaProduk.Size = new System.Drawing.Size(241, 22);
            this.Box_HargaProduk.TabIndex = 16;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(537, 106);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(49, 28);
            this.label16.TabIndex = 22;
            this.label16.Text = "QTY";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(681, 106);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(52, 28);
            this.label9.TabIndex = 17;
            this.label9.Text = "Stok";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(14, 56);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(104, 28);
            this.label5.TabIndex = 9;
            this.label5.Text = "Produk ID";
            // 
            // Box_IdProduk
            // 
            this.Box_IdProduk.Location = new System.Drawing.Point(135, 55);
            this.Box_IdProduk.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Box_IdProduk.Name = "Box_IdProduk";
            this.Box_IdProduk.ReadOnly = true;
            this.Box_IdProduk.Size = new System.Drawing.Size(70, 22);
            this.Box_IdProduk.TabIndex = 10;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(537, 64);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 28);
            this.label2.TabIndex = 21;
            this.label2.Text = "Kode";
            // 
            // Box_NamaProduk
            // 
            this.Box_NamaProduk.Location = new System.Drawing.Point(288, 61);
            this.Box_NamaProduk.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Box_NamaProduk.Name = "Box_NamaProduk";
            this.Box_NamaProduk.ReadOnly = true;
            this.Box_NamaProduk.Size = new System.Drawing.Size(241, 22);
            this.Box_NamaProduk.TabIndex = 14;
            // 
            // Box_KodeProduk
            // 
            this.Box_KodeProduk.Location = new System.Drawing.Point(603, 61);
            this.Box_KodeProduk.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Box_KodeProduk.Name = "Box_KodeProduk";
            this.Box_KodeProduk.ReadOnly = true;
            this.Box_KodeProduk.Size = new System.Drawing.Size(241, 22);
            this.Box_KodeProduk.TabIndex = 20;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(216, 61);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 28);
            this.label7.TabIndex = 13;
            this.label7.Text = "Nama";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.SteelBlue;
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.label21);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.Box_Diskon);
            this.panel3.Controls.Add(this.Box_JumlahBeli);
            this.panel3.Controls.Add(this.Box_SubTotal);
            this.panel3.Location = new System.Drawing.Point(1425, 596);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(408, 150);
            this.panel3.TabIndex = 75;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(12, 14);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(116, 28);
            this.label13.TabIndex = 76;
            this.label13.Text = "Jumlah Beli";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Black;
            this.label21.Location = new System.Drawing.Point(14, 103);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(96, 28);
            this.label21.TabIndex = 75;
            this.label21.Text = "Sub Total";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(14, 58);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(75, 28);
            this.label10.TabIndex = 74;
            this.label10.Text = "Diskon";
            // 
            // Box_Diskon
            // 
            this.Box_Diskon.Location = new System.Drawing.Point(136, 56);
            this.Box_Diskon.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Box_Diskon.Name = "Box_Diskon";
            this.Box_Diskon.ReadOnly = true;
            this.Box_Diskon.Size = new System.Drawing.Size(239, 22);
            this.Box_Diskon.TabIndex = 42;
            this.Box_Diskon.TextChanged += new System.EventHandler(this.Box_Diskon_TextChanged);
            // 
            // Box_JumlahBeli
            // 
            this.Box_JumlahBeli.Location = new System.Drawing.Point(136, 11);
            this.Box_JumlahBeli.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Box_JumlahBeli.Name = "Box_JumlahBeli";
            this.Box_JumlahBeli.Size = new System.Drawing.Size(239, 22);
            this.Box_JumlahBeli.TabIndex = 38;
            this.Box_JumlahBeli.TextChanged += new System.EventHandler(this.Box_JumlahBeli_TextChanged);
            // 
            // Box_SubTotal
            // 
            this.Box_SubTotal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Box_SubTotal.Location = new System.Drawing.Point(136, 100);
            this.Box_SubTotal.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Box_SubTotal.Name = "Box_SubTotal";
            this.Box_SubTotal.ReadOnly = true;
            this.Box_SubTotal.Size = new System.Drawing.Size(239, 22);
            this.Box_SubTotal.TabIndex = 33;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hapusItemToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(155, 28);
            // 
            // hapusItemToolStripMenuItem
            // 
            this.hapusItemToolStripMenuItem.Name = "hapusItemToolStripMenuItem";
            this.hapusItemToolStripMenuItem.Size = new System.Drawing.Size(154, 24);
            this.hapusItemToolStripMenuItem.Text = "Hapus Item";
            this.hapusItemToolStripMenuItem.Click += new System.EventHandler(this.hapusItemToolStripMenuItem_Click);
            // 
            // UcKasir
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel2);
            this.Name = "UcKasir";
            this.Size = new System.Drawing.Size(1853, 1083);
            this.Load += new System.EventHandler(this.UcKasir_Load);
            this.ControlRemoved += new System.Windows.Forms.ControlEventHandler(this.UcKasir_ControlRemoved);
            ((System.ComponentModel.ISupportInitialize)(this.db_KasirKSDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.joinTabelKasirBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tb_DetailPenjualanBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tb_PenjualanBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tb_ProdukBindingSource)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Db_KasirKSDataSet db_KasirKSDataSet;
        private System.Windows.Forms.BindingSource joinTabelKasirBindingSource;
        private Db_KasirKSDataSetTableAdapters.JoinTabelKasirTableAdapter joinTabelKasirTableAdapter;
        private Db_KasirKSDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private Db_KasirKSDataSetTableAdapters.Tb_DetailPenjualanTableAdapter tb_DetailPenjualanTableAdapter;
        private Db_KasirKSDataSetTableAdapters.Tb_PenjualanTableAdapter tb_PenjualanTableAdapter;
        private Db_KasirKSDataSetTableAdapters.Tb_ProdukTableAdapter tb_ProdukTableAdapter;
        private System.Windows.Forms.BindingSource tb_DetailPenjualanBindingSource;
        private System.Windows.Forms.BindingSource tb_PenjualanBindingSource;
        private System.Windows.Forms.BindingSource tb_ProdukBindingSource;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDetailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn namaAnggotaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kodeProdukDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn namaProdukDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kuantitasDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn hargaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn jumlahBeliDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn diskonDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn subTotalDataGridViewTextBoxColumn;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label18;
        internal System.Windows.Forms.Label GrandTotal;
        private System.Windows.Forms.Label label19;
        internal System.Windows.Forms.Label GrandBanyak;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btnBayarLangsung;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button btnBayar;
        internal System.Windows.Forms.TextBox Box_Bayar;
        private System.Windows.Forms.Label label14;
        internal System.Windows.Forms.TextBox Box_Kembalian;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label4;
        internal System.Windows.Forms.DateTimePicker Box_Tanggal;
        private System.Windows.Forms.Button btnTambahkan;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnPelangganUmum;
        private System.Windows.Forms.Button btnListAnggota;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label8;
        internal System.Windows.Forms.TextBox Box_NamaAnggota;
        internal System.Windows.Forms.TextBox Box_IdAnggota;
        internal System.Windows.Forms.TextBox Box_Kuantitas;
        internal System.Windows.Forms.TextBox Box_StokProduk;
        private System.Windows.Forms.Button btnListProduk;
        internal System.Windows.Forms.TextBox Box_HargaProduk;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label5;
        internal System.Windows.Forms.TextBox Box_IdProduk;
        private System.Windows.Forms.Label label2;
        internal System.Windows.Forms.TextBox Box_NamaProduk;
        internal System.Windows.Forms.TextBox Box_KodeProduk;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label10;
        internal System.Windows.Forms.TextBox Box_Diskon;
        internal System.Windows.Forms.TextBox Box_JumlahBeli;
        internal System.Windows.Forms.TextBox Box_SubTotal;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem hapusItemToolStripMenuItem;
    }
}
