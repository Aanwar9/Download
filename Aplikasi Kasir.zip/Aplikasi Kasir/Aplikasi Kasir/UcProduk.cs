﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aplikasi_Kasir
{
    public partial class UcProduk : UserControl
    {
        public UcProduk()
        {
            InitializeComponent();
        }
        // =========================
        // LOAD & INIT
        // =========================
        private void UcProduk_Load(object sender, EventArgs e)
        {
            tb_ProdukTableAdapter.Fill(db_KasirKSDataSet.Tb_Produk);

            InisialisasiComboBox();
            LoadDataProduk();
            TampilkanTotalProduk();
        }
        private void InisialisasiComboBox()
        {
            comboBox1.Items.AddRange(new object[]
            {
                "ID Produk",
                "Kode Produk",
                "Nama Produk",
                "Harga",
                "Kuantitas",
                "Stok",
                "Keterangan"
            });

            comboBox2.Items.AddRange(new object[]
            {
                "Ascending",
                "Descending"
            });

            comboBox1.SelectedIndex = 0;
            comboBox2.SelectedIndex = 0;
        }

        // =========================
        // LOAD & UTIL
        // =========================
        private void LoadDataProduk()
        {
            dataGridView1.DataSource = tb_ProdukTableAdapter.GetData().ToList();
        }

        private void TampilkanTotalProduk()
        {
            int total = dataGridView1.Rows
                .Cast<DataGridViewRow>()
                .Count(r => !r.IsNewRow);

            labelTotalProduk.Text = "Produk:" + Environment.NewLine + total;
        }

        private void ClearTextBoxes()
        {
            Box_IdProduk.Clear();
            Box_KodeProduk.Clear();
            Box_NamaProduk.Clear();
            Box_Harga.Clear();
            Box_Kuantitas.Clear();
            Box_Stok.Clear();
            Box_Keterangan.Clear();
        }

        // =========================
        // SORTING
        // =========================
        private void LakukanSortingProduk()
        {
            if (comboBox1.SelectedItem == null || comboBox2.SelectedItem == null)
                return;

            var data = dataGridView1.DataSource as
                System.Collections.Generic.List<Db_KasirKSDataSet.Tb_ProdukRow>;

            if (data == null || data.Count == 0)
                return;

            bool asc = comboBox2.SelectedItem.ToString() == "Ascending";

            switch (comboBox1.SelectedItem.ToString())
            {
                case "ID Produk":
                    data = asc ? data.OrderBy(x => x.ID_Produk).ToList()
                               : data.OrderByDescending(x => x.ID_Produk).ToList();
                    break;

                case "Kode Produk":
                    data = asc ? data.OrderBy(x => x.Kode_Produk).ToList()
                               : data.OrderByDescending(x => x.Kode_Produk).ToList();
                    break;

                case "Nama Produk":
                    data = asc ? data.OrderBy(x => x.Nama_Produk).ToList()
                               : data.OrderByDescending(x => x.Nama_Produk).ToList();
                    break;

                case "Harga":
                    data = asc ? data.OrderBy(x => x.Harga).ToList()
                               : data.OrderByDescending(x => x.Harga).ToList();
                    break;

                case "Kuantitas":
                    data = asc ? data.OrderBy(x => x.Kuantitas).ToList()
                               : data.OrderByDescending(x => x.Kuantitas).ToList();
                    break;

                case "Stok":
                    data = asc ? data.OrderBy(x => x.Stok).ToList()
                               : data.OrderByDescending(x => x.Stok).ToList();
                    break;

                case "Keterangan":
                    data = asc ? data.OrderBy(x => x.Keterangan).ToList()
                               : data.OrderByDescending(x => x.Keterangan).ToList();
                    break;
            }

            dataGridView1.DataSource = data;
        }
        // =========================
        // GRID EVENT
        // =========================
        private void dataGridView1_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            var row = dataGridView1.Rows[e.RowIndex];

            Box_IdProduk.Text = row.Cells[0].Value.ToString();
            Box_KodeProduk.Text = row.Cells[1].Value.ToString();
            Box_NamaProduk.Text = row.Cells[2].Value.ToString();
            Box_Harga.Text = row.Cells[3].Value.ToString();
            Box_Kuantitas.Text = row.Cells[4].Value.ToString();
            Box_Stok.Text = row.Cells[5].Value.ToString();
            Box_Keterangan.Text = row.Cells[6].Value.ToString();
        }
        // =========================
        // CRUD
        // =========================
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                tb_ProdukTableAdapter.TambahProduk(
                    Convert.ToInt32(Box_IdProduk.Text),
                    Box_KodeProduk.Text,
                    Box_NamaProduk.Text,
                    Convert.ToDecimal(Box_Harga.Text),
                    Box_Kuantitas.Text,
                    Convert.ToInt32(Box_Stok.Text),
                    Box_Keterangan.Text
                );

                LoadDataProduk();
                TampilkanTotalProduk();

                MessageBox.Show("Data produk berhasil ditambahkan!",
                    "Sukses", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0) return;

            if (MessageBox.Show("Hapus data produk ini?", "Konfirmasi",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            try
            {
                int id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
                tb_ProdukTableAdapter.HapusProduk(id);

                LoadDataProduk();
                TampilkanTotalProduk();
                ClearTextBoxes();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Box_IdProduk.Text)) return;

            try
            {
                tb_ProdukTableAdapter.UpdateProduk(
                    Convert.ToInt32(Box_IdProduk.Text),
                    Box_KodeProduk.Text,
                    Box_NamaProduk.Text,
                    Convert.ToDecimal(Box_Harga.Text),
                    Box_Kuantitas.Text,
                    Convert.ToInt32(Box_Stok.Text),
                    Box_Keterangan.Text
                );

                LoadDataProduk();
                TampilkanTotalProduk();
                ClearTextBoxes();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        // =========================
        // FILTER
        // =========================
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string filter = textBox1.Text.Trim();
            var data = tb_ProdukTableAdapter.GetData();

            if (string.IsNullOrEmpty(filter))
            {
                dataGridView1.DataSource = data.ToList();
                LakukanSortingProduk();
                return;
            }

            System.Collections.Generic.List<Db_KasirKSDataSet.Tb_ProdukRow> hasil = null;

            switch (comboBox1.SelectedItem.ToString())
            {
                case "ID Produk":
                    hasil = data.Where(x => x.ID_Produk.ToString().Contains(filter)).ToList();
                    break;
                case "Kode Produk":
                    hasil = data.Where(x => x.Kode_Produk.Contains(filter)).ToList();
                    break;
                case "Nama Produk":
                    hasil = data.Where(x => x.Nama_Produk.Contains(filter)).ToList();
                    break;
                case "Harga":
                    hasil = data.Where(x => x.Harga.ToString().Contains(filter)).ToList();
                    break;
                case "Kuantitas":
                    hasil = data.Where(x => x.Kuantitas.Contains(filter)).ToList();
                    break;
                case "Stok":
                    hasil = data.Where(x => x.Stok.ToString().Contains(filter)).ToList();
                    break;
                case "Keterangan":
                    hasil = data.Where(x => x.Keterangan.Contains(filter)).ToList();
                    break;
            }

            dataGridView1.DataSource = hasil;
            LakukanSortingProduk();
        }
        // =========================
        // UI EVENT
        // =========================
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            ClearTextBoxes();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            LakukanSortingProduk();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            LakukanSortingProduk();
        }
    }
}
