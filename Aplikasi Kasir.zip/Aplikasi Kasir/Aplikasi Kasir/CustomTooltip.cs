﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aplikasi_Kasir
{
    public class CustomTooltip : Form
    {
        private Label lblText;

        public CustomTooltip(string text)
        {
            this.FormBorderStyle = FormBorderStyle.None;
            this.StartPosition = FormStartPosition.Manual;
            this.BackColor = Color.FromArgb(45, 45, 45);
            this.AutoSize = true;
            this.ShowInTaskbar = false;
            this.TopMost = true;
            this.Padding = new Padding(8, 4, 8, 4);

            lblText = new Label()
            {
                Text = text,
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 9f),
                AutoSize = true,
                BackColor = Color.Transparent
            };

            this.Controls.Add(lblText);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            GraphicsPath path = new GraphicsPath();
            int radius = 6;

            path.AddArc(0, 0, radius, radius, 180, 90);
            path.AddArc(Width - radius, 0, radius, radius, 270, 90);
            path.AddArc(Width - radius, Height - radius, radius, radius, 0, 90);
            path.AddArc(0, Height - radius, radius, radius, 90, 90);
            path.CloseFigure();

            this.Region = new Region(path);
        }
    }
}
